-- 修复users表结构，添加缺失的字段
USE shopping_platform;

-- 检查并添加phone字段
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS phone VARCHAR(20) NULL COMMENT '手机号' 
AFTER email;

-- 检查并添加address字段  
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS address TEXT NULL COMMENT '地址' 
AFTER phone;

-- 检查并添加create_time字段
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL COMMENT '创建时间' 
AFTER address;

-- 检查并添加update_time字段
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL COMMENT '更新时间' 
AFTER create_time;

-- 显示表结构确认
DESCRIBE users;