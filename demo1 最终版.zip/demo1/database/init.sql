-- 简易商品购物平台数据库初始化脚本
-- 创建数据库
CREATE DATABASE IF NOT EXISTS shopping_platform 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE shopping_platform;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码(MD5加密)',
    email VARCHAR(100) NOT NULL UNIQUE COMMENT '邮箱',
    phone VARCHAR(20) COMMENT '手机号',
    address TEXT COMMENT '地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 商家表
CREATE TABLE IF NOT EXISTS merchants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    merchant_name VARCHAR(50) NOT NULL UNIQUE COMMENT '商家名称',
    password VARCHAR(255) NOT NULL COMMENT '密码(MD5加密)',
    contact_email VARCHAR(100) NOT NULL UNIQUE COMMENT '联系邮箱',
    phone VARCHAR(20) COMMENT '联系电话',
    address TEXT COMMENT '地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_merchant_name (merchant_name),
    INDEX idx_contact_email (contact_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商家表';

-- 商品表
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL COMMENT '商品名称',
    description TEXT COMMENT '商品描述',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    stock INT NOT NULL DEFAULT 0 COMMENT '库存数量',
    image_url VARCHAR(500) COMMENT '商品图片URL',
    merchant_id INT NOT NULL COMMENT '商家ID',
    status VARCHAR(20) NOT NULL DEFAULT 'active' COMMENT '状态: active(在售), inactive(下架), low_stock(库存不足)',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (merchant_id) REFERENCES merchants(id) ON DELETE CASCADE,
    INDEX idx_merchant_id (merchant_id),
    INDEX idx_status (status),
    INDEX idx_name (name),
    INDEX idx_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- 购物车表
CREATE TABLE IF NOT EXISTS cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    product_id INT NOT NULL COMMENT '商品ID',
    quantity INT NOT NULL DEFAULT 1 COMMENT '数量',
    price DECIMAL(10,2) NOT NULL COMMENT '添加时的价格',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY uk_user_product (user_id, product_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- 订单表
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(50) NOT NULL UNIQUE COMMENT '订单号',
    user_id INT NOT NULL COMMENT '用户ID',
    total_amount DECIMAL(10,2) NOT NULL COMMENT '订单总金额',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '订单状态: pending(待付款), paid(已付款), shipped(已发货), delivered(已送达), cancelled(已取消), refunded(已退款)',
    receiver_name VARCHAR(100) NOT NULL COMMENT '收货人姓名',
    receiver_phone VARCHAR(20) NOT NULL COMMENT '收货人电话',
    receiver_address TEXT NOT NULL COMMENT '收货地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_order_no (order_no),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 订单项表
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL COMMENT '订单ID',
    product_id INT NOT NULL COMMENT '商品ID',
    product_name VARCHAR(200) NOT NULL COMMENT '商品名称(冗余字段)',
    price DECIMAL(10,2) NOT NULL COMMENT '单价',
    quantity INT NOT NULL COMMENT '数量',
    subtotal DECIMAL(10,2) NOT NULL COMMENT '小计金额',
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单项表';

-- 商品评价表
CREATE TABLE IF NOT EXISTS comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    product_id INT NOT NULL COMMENT '商品ID',
    order_id INT NOT NULL COMMENT '订单ID',
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5) COMMENT '评分(1-5星)',
    content TEXT COMMENT '评价内容',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    UNIQUE KEY uk_user_order (user_id, order_id),
    INDEX idx_product_id (product_id),
    INDEX idx_user_id (user_id),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品评价表';

-- 退款申请表
CREATE TABLE IF NOT EXISTS refunds (
    id INT PRIMARY KEY AUTO_INCREMENT,
    refund_no VARCHAR(50) NOT NULL UNIQUE COMMENT '退款单号',
    user_id INT NOT NULL COMMENT '用户ID',
    order_id INT NOT NULL COMMENT '订单ID',
    order_item_id INT NOT NULL COMMENT '订单项ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '退款金额',
    reason TEXT NOT NULL COMMENT '退款原因',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending(待审核), approved(已同意), rejected(已拒绝), processed(已处理)',
    merchant_note TEXT COMMENT '商家备注',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id),
    INDEX idx_status (status),
    INDEX idx_refund_no (refund_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款申请表';

-- 插入测试数据
-- 插入测试商家
INSERT INTO merchants (merchant_name, password, contact_email, phone, address) VALUES
('testmerchant', MD5('123456'), 'merchant@test.com', '13800138000', '北京市朝阳区测试地址123号'),
('科技商店', MD5('123456'), 'tech@shop.com', '13900139000', '上海市浦东新区张江高科技园区'),
('生活超市', MD5('123456'), 'life@supermarket.com', '13700137000', '广州市天河区珠江新城');

-- 插入测试用户
INSERT INTO users (username, password, email, phone, address) VALUES
('testuser', MD5('123456'), 'user@test.com', '13600136000', '深圳市南山区科技园'),
('张三', MD5('123456'), 'zhangsan@test.com', '13500135000', '成都市高新区天府大道'),
('李四', MD5('123456'), 'lisi@test.com', '13400134000', '杭州市西湖区文三路');

-- 插入测试商品
INSERT INTO products (name, description, price, stock, merchant_id, status) VALUES
('iPhone 15 Pro', '苹果最新款智能手机，钛金属机身，A17 Pro芯片', 8999.00, 15, 1, 'low_stock'),
('MacBook Pro 16', '苹果笔记本电脑，M3 Max芯片，16英寸液晶屏', 25999.00, 8, 1, 'low_stock'),
('AirPods Pro', '苹果无线耳机，主动降噪，空间音频', 1999.00, 50, 2, 'active'),
('小米14 Ultra', '小米旗舰手机，徕卡影像，骁龙8 Gen3', 6499.00, 25, 2, 'active'),
('华为Mate 60 Pro', '华为旗舰手机，卫星通话，鸿蒙系统', 6999.00, 12, 3, 'low_stock'),
('戴森吸尘器V15', '戴森无线吸尘器，激光探测，智能调节', 4990.00, 30, 3, 'active'),
('索尼PS5', '索尼游戏主机，4K游戏，光驱版', 3899.00, 20, 1, 'active'),
('Nintendo Switch', '任天堂游戏机，主机+掌机一体', 2099.00, 35, 2, 'active'),
('小米电视75寸', '小米智能电视，4K HDR，小爱同学', 4999.00, 18, 3, 'low_stock'),
('iPad Pro 12.9', '苹果平板电脑，M2芯片，Liquid视网膜屏', 9299.00, 22, 1, 'active');

-- 创建视图：商品统计
CREATE OR REPLACE VIEW v_product_stats AS
SELECT 
    p.merchant_id,
    m.merchant_name,
    COUNT(*) as total_products,
    SUM(CASE WHEN p.status = 'active' AND p.stock > 0 THEN 1 ELSE 0 END) as active_products,
    SUM(CASE WHEN p.status = 'low_stock' THEN 1 ELSE 0 END) as low_stock_products,
    SUM(CASE WHEN p.status = 'inactive' OR p.stock <= 0 THEN 1 ELSE 0 END) as inactive_products,
    AVG(p.price) as avg_price,
    MIN(p.price) as min_price,
    MAX(p.price) as max_price,
    SUM(p.stock) as total_stock
FROM products p
LEFT JOIN merchants m ON p.merchant_id = m.id
GROUP BY p.merchant_id, m.merchant_name;

-- 创建视图：订单统计
CREATE OR REPLACE VIEW v_order_stats AS
SELECT 
    DATE(create_time) as order_date,
    COUNT(*) as order_count,
    SUM(total_amount) as total_amount,
    AVG(total_amount) as avg_amount,
    COUNT(DISTINCT user_id) as unique_users
FROM orders
GROUP BY DATE(create_time)
ORDER BY order_date DESC;

-- 创建存储过程：生成退款单号
DELIMITER //
CREATE PROCEDURE generate_refund_no()
BEGIN
    DECLARE refund_no VARCHAR(50);
    SET refund_no = CONCAT('REF', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
    SELECT refund_no;
END //
DELIMITER ;

-- 创建触发器：自动更新商品状态
DELIMITER //
CREATE TRIGGER trg_product_status_update 
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN
    IF NEW.stock != OLD.stock THEN
        IF NEW.stock <= 0 THEN
            SET NEW.status = 'inactive';
        ELSEIF NEW.stock <= 10 THEN
            SET NEW.status = 'low_stock';
        ELSE
            SET NEW.status = 'active';
        END IF;
    END IF;
END //
DELIMITER ;

-- 添加索引优化查询性能
CREATE INDEX idx_products_status_stock ON products(status, stock);
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_refunds_status_create ON refunds(status, create_time);

-- 设置数据库字符集
ALTER DATABASE shopping_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;