-- =====================================================
-- 简易商品购物平台完整数据库创建脚本
-- =====================================================

-- 删除已存在的数据库（谨慎使用）
-- DROP DATABASE IF EXISTS shopping_platform;

-- 创建数据库
CREATE DATABASE IF NOT EXISTS shopping_platform 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE shopping_platform;

-- =====================================================
-- 1. 用户表 (users)
-- =====================================================
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '用户ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码(MD5加密)',
    email VARCHAR(100) NOT NULL UNIQUE COMMENT '邮箱',
    phone VARCHAR(20) NULL COMMENT '手机号',
    address TEXT NULL COMMENT '收货地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- =====================================================
-- 2. 商家表 (merchants)
-- =====================================================
DROP TABLE IF EXISTS merchants;
CREATE TABLE merchants (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '商家ID',
    merchant_name VARCHAR(50) NOT NULL UNIQUE COMMENT '商家名称',
    password VARCHAR(255) NOT NULL COMMENT '密码(MD5加密)',
    contact_email VARCHAR(100) NOT NULL UNIQUE COMMENT '联系邮箱',
    phone VARCHAR(20) NULL COMMENT '联系电话',
    address TEXT NULL COMMENT '商家地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_merchant_name (merchant_name),
    INDEX idx_contact_email (contact_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商家表';

-- =====================================================
-- 3. 商品表 (products)
-- =====================================================
DROP TABLE IF EXISTS products;
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '商品ID',
    name VARCHAR(200) NOT NULL COMMENT '商品名称',
    description TEXT NULL COMMENT '商品描述',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    stock INT NOT NULL DEFAULT 0 COMMENT '库存数量',
    image_url VARCHAR(500) NULL COMMENT '商品图片URL',
    merchant_id INT NOT NULL COMMENT '商家ID',
    status VARCHAR(20) NOT NULL DEFAULT 'active' COMMENT '状态: active(在售), inactive(下架), low_stock(库存不足)',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (merchant_id) REFERENCES merchants(id) ON DELETE CASCADE,
    INDEX idx_merchant_id (merchant_id),
    INDEX idx_status (status),
    INDEX idx_name (name),
    INDEX idx_price (price),
    INDEX idx_stock (stock),
    INDEX idx_status_stock (status, stock)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- =====================================================
-- 4. 购物车表 (cart)
-- =====================================================
DROP TABLE IF EXISTS cart;
CREATE TABLE cart (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '购物车ID',
    user_id INT NOT NULL COMMENT '用户ID',
    product_id INT NOT NULL COMMENT '商品ID',
    quantity INT NOT NULL DEFAULT 1 COMMENT '数量',
    price DECIMAL(10,2) NOT NULL COMMENT '添加时的价格',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY uk_user_product (user_id, product_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- =====================================================
-- 5. 订单表 (orders)
-- =====================================================
DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '订单ID',
    order_no VARCHAR(50) NOT NULL UNIQUE COMMENT '订单号',
    user_id INT NOT NULL COMMENT '用户ID',
    total_amount DECIMAL(10,2) NOT NULL COMMENT '订单总金额',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '订单状态: pending(待付款), paid(已付款), shipped(已发货), delivered(已送达), cancelled(已取消), refunded(已退款)',
    receiver_name VARCHAR(100) NOT NULL COMMENT '收货人姓名',
    receiver_phone VARCHAR(20) NOT NULL COMMENT '收货人电话',
    receiver_address TEXT NOT NULL COMMENT '收货地址',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_order_no (order_no),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time),
    INDEX idx_user_status (user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- =====================================================
-- 6. 订单项表 (order_items)
-- =====================================================
DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '订单项ID',
    order_id INT NOT NULL COMMENT '订单ID',
    product_id INT NOT NULL COMMENT '商品ID',
    product_name VARCHAR(200) NOT NULL COMMENT '商品名称(冗余字段)',
    price DECIMAL(10,2) NOT NULL COMMENT '单价',
    quantity INT NOT NULL COMMENT '数量',
    subtotal DECIMAL(10,2) NOT NULL COMMENT '小计金额',
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单项表';

-- =====================================================
-- 7. 商品评价表 (comments)
-- =====================================================
DROP TABLE IF EXISTS comments;
CREATE TABLE comments (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '评价ID',
    user_id INT NOT NULL COMMENT '用户ID',
    product_id INT NOT NULL COMMENT '商品ID',
    order_id INT NOT NULL COMMENT '订单ID',
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5) COMMENT '评分(1-5星)',
    content TEXT NULL COMMENT '评价内容',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    UNIQUE KEY uk_user_order (user_id, order_id),
    INDEX idx_product_id (product_id),
    INDEX idx_user_id (user_id),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品评价表';

-- =====================================================
-- 8. 退款申请表 (refunds)
-- =====================================================
DROP TABLE IF EXISTS refunds;
CREATE TABLE refunds (
    id INT PRIMARY KEY AUTO_INCREMENT COMMENT '退款ID',
    refund_no VARCHAR(50) NOT NULL UNIQUE COMMENT '退款单号',
    user_id INT NOT NULL COMMENT '用户ID',
    order_id INT NOT NULL COMMENT '订单ID',
    order_item_id INT NOT NULL COMMENT '订单项ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '退款金额',
    reason TEXT NOT NULL COMMENT '退款原因',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending(待审核), approved(已同意), rejected(已拒绝), processed(已处理)',
    merchant_note TEXT NULL COMMENT '商家备注',
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id),
    INDEX idx_status (status),
    INDEX idx_refund_no (refund_no),
    INDEX idx_status_create (status, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款申请表';

-- =====================================================
-- 9. 创建视图
-- =====================================================

-- 商品统计视图
DROP VIEW IF EXISTS v_product_stats;
CREATE VIEW v_product_stats AS
SELECT 
    p.merchant_id,
    m.merchant_name,
    COUNT(*) as total_products,
    SUM(CASE WHEN p.status = 'active' AND p.stock > 0 THEN 1 ELSE 0 END) as active_products,
    SUM(CASE WHEN p.status = 'low_stock' THEN 1 ELSE 0 END) as low_stock_products,
    SUM(CASE WHEN p.status = 'inactive' OR p.stock <= 0 THEN 1 ELSE 0 END) as inactive_products,
    AVG(p.price) as avg_price,
    MIN(p.price) as min_price,
    MAX(p.price) as max_price,
    SUM(p.stock) as total_stock
FROM products p
LEFT JOIN merchants m ON p.merchant_id = m.id
GROUP BY p.merchant_id, m.merchant_name;

-- 订单统计视图
DROP VIEW IF EXISTS v_order_stats;
CREATE VIEW v_order_stats AS
SELECT 
    DATE(create_time) as order_date,
    COUNT(*) as order_count,
    SUM(total_amount) as total_amount,
    AVG(total_amount) as avg_amount,
    COUNT(DISTINCT user_id) as unique_users
FROM orders
GROUP BY DATE(create_time)
ORDER BY order_date DESC;

-- 用户订单视图
DROP VIEW IF EXISTS v_user_orders;
CREATE VIEW v_user_orders AS
SELECT 
    u.id as user_id,
    u.username,
    u.email,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as total_spent,
    AVG(o.total_amount) as avg_order_value,
    MAX(o.create_time) as last_order_date
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.username, u.email;

-- =====================================================
-- 10. 创建存储过程
-- =====================================================

-- 生成退款单号的存储过程
DELIMITER //
DROP PROCEDURE IF EXISTS generate_refund_no//
CREATE PROCEDURE generate_refund_no()
BEGIN
    DECLARE refund_no VARCHAR(50);
    SET refund_no = CONCAT('REF', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
    SELECT refund_no;
END //
DELIMITER ;

-- 生成订单号的存储过程
DELIMITER //
DROP PROCEDURE IF EXISTS generate_order_no//
CREATE PROCEDURE generate_order_no()
BEGIN
    DECLARE order_no VARCHAR(50);
    SET order_no = CONCAT('ORD', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
    SELECT order_no;
END //
DELIMITER ;

-- =====================================================
-- 11. 创建触发器
-- =====================================================

-- 商品状态自动更新触发器
DELIMITER //
DROP TRIGGER IF EXISTS trg_product_status_update//
CREATE TRIGGER trg_product_status_update 
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN
    IF NEW.stock != OLD.stock THEN
        IF NEW.stock <= 0 THEN
            SET NEW.status = 'inactive';
        ELSEIF NEW.stock <= 10 THEN
            SET NEW.status = 'low_stock';
        ELSE
            SET NEW.status = 'active';
        END IF;
    END IF;
END //
DELIMITER ;

-- 插入商品时设置状态触发器
DELIMITER //
DROP TRIGGER IF EXISTS trg_product_status_insert//
CREATE TRIGGER trg_product_status_insert 
BEFORE INSERT ON products
FOR EACH ROW
BEGIN
    IF NEW.stock <= 0 THEN
        SET NEW.status = 'inactive';
    ELSEIF NEW.stock <= 10 THEN
        SET NEW.status = 'low_stock';
    ELSE
        SET NEW.status = 'active';
    END IF;
END //
DELIMITER ;

-- =====================================================
-- 12. 添加索引优化
-- =====================================================

-- 复合索引优化查询性能
CREATE INDEX idx_products_merchant_status ON products(merchant_id, status);
CREATE INDEX idx_orders_user_status_date ON orders(user_id, status, create_time);
CREATE INDEX idx_refunds_status_create ON refunds(status, create_time);
CREATE INDEX idx_comments_product_rating ON comments(product_id, rating);
CREATE INDEX idx_cart_user_product ON cart(user_id, product_id);

-- =====================================================
-- 13. 插入测试数据
-- =====================================================

-- 插入测试商家数据
INSERT INTO merchants (merchant_name, password, contact_email, phone, address) VALUES
('testmerchant', MD5('123456'), 'merchant@test.com', '13800138000', '北京市朝阳区测试地址123号'),
('科技商店', MD5('123456'), 'tech@shop.com', '13900139000', '上海市浦东新区张江高科技园区'),
('生活超市', MD5('123456'), 'life@supermarket.com', '13700137000', '广州市天河区珠江新城'),
('数码专营', MD5('123456'), 'digital@shop.com', '13600136000', '深圳市南山区科技园'),
('时尚服饰', MD5('123456'), 'fashion@shop.com', '13500135000', '杭州市西湖区文三路');

-- 插入测试用户数据
INSERT INTO users (username, password, email, phone, address) VALUES
('testuser', MD5('123456'), 'user@test.com', '13600136000', '深圳市南山区科技园'),
('张三', MD5('123456'), 'zhangsan@test.com', '13500135000', '成都市高新区天府大道'),
('李四', MD5('123456'), 'lisi@test.com', '13400134000', '杭州市西湖区文三路'),
('王五', MD5('123456'), 'wangwu@test.com', '13300133000', '北京市朝阳区望京'),
('赵六', MD5('123456'), 'zhaoliu@test.com', '13200132000', '广州市天河区体育西路');

-- 插入测试商品数据
INSERT INTO products (name, description, price, stock, merchant_id, image_url) VALUES
('iPhone 15 Pro', '苹果最新款智能手机，钛金属机身，A17 Pro芯片，支持5G网络', 8999.00, 15, 1, '/images/iphone15pro.jpg'),
('MacBook Pro 16', '苹果笔记本电脑，M3 Max芯片，16英寸液晶屏，32GB内存', 25999.00, 8, 1, '/images/macbookpro16.jpg'),
('AirPods Pro', '苹果无线耳机，主动降噪，空间音频，无线充电', 1999.00, 50, 2, '/images/airpodspro.jpg'),
('小米14 Ultra', '小米旗舰手机，徕卡影像，骁龙8 Gen3，1英寸大底', 6499.00, 25, 2, '/images/xiaomi14ultra.jpg'),
('华为Mate 60 Pro', '华为旗舰手机，卫星通话，鸿蒙系统4.0，昆仑玻璃', 6999.00, 12, 3, '/images/huaweiMate60pro.jpg'),
('戴森吸尘器V15', '戴森无线吸尘器，激光探测，智能调节，60分钟续航', 4990.00, 30, 3, '/images/dysonv15.jpg'),
('索尼PS5', '索尼游戏主机，4K游戏，光驱版，1TB固态硬盘', 3899.00, 20, 1, '/images/ps5.jpg'),
('Nintendo Switch', '任天堂游戏机，主机+掌机一体，OLED屏幕', 2099.00, 35, 2, '/images/switch.jpg'),
('小米电视75寸', '小米智能电视，4K HDR，小爱同学，杜比视界', 4999.00, 18, 3, '/images/mitv75.jpg'),
('iPad Pro 12.9', '苹果平板电脑，M2芯片，Liquid视网膜屏，支持Apple Pencil', 9299.00, 22, 1, '/images/ipadpro129.jpg'),
('Samsung Galaxy S24', '三星旗舰手机，AI功能，5000万像素，120Hz屏幕', 5999.00, 28, 4, '/images/galaxys24.jpg'),
('ThinkPad X1 Carbon', '联想商务笔记本，Intel i7，14英寸2.8K屏幕，16GB内存', 12999.00, 15, 4, '/images/thinkpadx1.jpg'),
('Nike Air Max', '耐克运动鞋，气垫缓震，透气网面，经典设计', 899.00, 60, 5, '/images/nikeairmax.jpg'),
('Adidas运动套装', '阿迪达斯运动服，速干面料，修身剪裁，多色可选', 599.00, 45, 5, '/images/adidasset.jpg'),
('Sony WH-1000XM5', '索尼降噪耳机，30小时续航，高解析度音频', 2499.00, 25, 4, '/images/sonyxm5.jpg');

-- =====================================================
-- 14. 显示创建结果
-- =====================================================

SELECT 'Database: shopping_platform created successfully!' as result;
SHOW TABLES;

-- 显示各表的记录数
SELECT 
    TABLE_NAME as '表名',
    TABLE_ROWS as '记录数'
FROM 
    information_schema.TABLES 
WHERE 
    TABLE_SCHEMA = 'shopping_platform'
ORDER BY 
    TABLE_NAME;

-- 显示用户表结构
DESCRIBE users;

-- =====================================================
-- 15. 使用说明
-- =====================================================

/*
数据库创建完成后，可以使用以下命令验证：

1. 连接数据库：
   mysql -u root -p shopping_platform

2. 查看所有表：
   SHOW TABLES;

3. 查看用户数据：
   SELECT * FROM users;

4. 查看商品数据：
   SELECT * FROM products;

5. 测试存储过程：
   CALL generate_order_no();
   CALL generate_refund_no();

6. 查看视图数据：
   SELECT * FROM v_product_stats;
   SELECT * FROM v_order_stats;

测试账户：
商家：testmerchant / 123456
用户：testuser / 123456

数据库字符集：utf8mb4
排序规则：utf8mb4_unicode_ci
存储引擎：InnoDB
*/