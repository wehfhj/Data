package com.example.demo1.service;

import com.example.demo1.dao.UserDAO;
import com.example.demo1.entity.User;
import com.example.demo1.util.ValidationUtil;

import java.sql.SQLException;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    public void register(User user) throws SQLException {
        // 验证用户名格式
        if (!ValidationUtil.isValidUsername(user.getUsername())) {
            throw new IllegalArgumentException("用户名格式不正确，长度应为3-20个字符");
        }

        // 验证密码格式
        if (!ValidationUtil.isValidPassword(user.getPassword())) {
            throw new IllegalArgumentException("密码格式不正确，长度应为6-20个字符，包含字母和数字");
        }

        // 验证邮箱格式
        if (!ValidationUtil.isValidEmail(user.getEmail())) {
            throw new IllegalArgumentException("邮箱格式不正确");
        }

        // 验证手机号格式
        if (!ValidationUtil.isValidPhone(user.getPhone())) {
            throw new IllegalArgumentException("手机号格式不正确");
        }

        // 检查用户名是否已存在
        if (userDAO.getByUsername(user.getUsername()) != null) {
            throw new IllegalArgumentException("用户名已存在");
        }

        // 检查邮箱是否已存在
        if (userDAO.getByEmail(user.getEmail()) != null) {
            throw new IllegalArgumentException("邮箱已存在");
        }

        // 注册用户
        userDAO.add(user);
    }

    public User login(String username, String password) throws SQLException {
        User user = userDAO.getByUsername(username);
        if (user == null || !user.getPassword().equals(password)) {
            throw new IllegalArgumentException("用户名或密码错误");
        }
        return user;
    }

    public User getUserById(int id) throws SQLException {
        User user = userDAO.getById(id);
        if (user == null) {
            throw new IllegalArgumentException("用户不存在");
        }
        return user;
    }

    public void updateUser(User user) throws SQLException {
        // 验证邮箱格式
        if (!ValidationUtil.isValidEmail(user.getEmail())) {
            throw new IllegalArgumentException("邮箱格式不正确");
        }

        // 验证手机号格式
        if (!ValidationUtil.isValidPhone(user.getPhone())) {
            throw new IllegalArgumentException("手机号格式不正确");
        }

        // 检查邮箱是否被其他用户使用
        User existingUser = userDAO.getByEmail(user.getEmail());
        if (existingUser != null && existingUser.getId() != user.getId()) {
            throw new IllegalArgumentException("邮箱已被其他用户使用");
        }

        // 更新用户信息
        userDAO.update(user);
    }

    public void changePassword(int userId, String oldPassword, String newPassword) throws SQLException {
        User user = userDAO.getById(userId);
        if (user == null) {
            throw new IllegalArgumentException("用户不存在");
        }

        // 验证旧密码
        if (!user.getPassword().equals(oldPassword)) {
            throw new IllegalArgumentException("旧密码错误");
        }

        // 验证新密码格式
        if (!ValidationUtil.isValidPassword(newPassword)) {
            throw new IllegalArgumentException("新密码格式不正确，长度应为6-20个字符，包含字母和数字");
        }

        // 更新密码
        user.setPassword(newPassword);
        userDAO.update(user);
    }
}