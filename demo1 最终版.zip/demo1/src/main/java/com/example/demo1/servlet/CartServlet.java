package com.example.demo1.servlet;

import com.example.demo1.entity.Cart;
import com.example.demo1.entity.Product;
import com.example.demo1.entity.User;
import com.example.demo1.service.CartService;
import com.example.demo1.service.ProductService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/cart/*")
public class CartServlet extends HttpServlet {
    
    private CartService cartService = new CartService();
    private ProductService productService = new ProductService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 检查用户登录状态
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            String pathInfo = request.getPathInfo();
            if (pathInfo == null || pathInfo.equals("/")) {
                // 显示购物车列表
                listCart(request, response, user);
            } else if (pathInfo.equals("/delete")) {
                // 删除购物车商品
                deleteCartItem(request, response, user);
            } else if (pathInfo.equals("/clear")) {
                // 清空购物车
                clearCart(request, response, user);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            
        } catch (Exception e) {
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 设置请求编码
        request.setCharacterEncoding("UTF-8");

        // 检查用户登录状态
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            String pathInfo = request.getPathInfo();
            if (pathInfo == null || pathInfo.equals("/")) {
                // 添加商品到购物车
                addToCart(request, response, user);
            } else if (pathInfo.equals("/update")) {
                // 更新购物车商品数量
                updateCartItem(request, response, user);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
            
        } catch (Exception e) {
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    /**
     * 显示购物车列表
     */
    private void listCart(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        System.out.println("===== 开始查询购物车 =====");
        System.out.println("用户ID: " + user.getId());
        
        try {
            System.out.println("正在查询购物车...");
            List<Cart> cartItems = cartService.getCartByUserId(user.getId());
            System.out.println("查询到购物车商品数量: " + cartItems.size());
            
            double total = 0;
            for (Cart cart : cartItems) {
                total += cart.getPrice() * cart.getQuantity();
            }
            System.out.println("购物车总金额: ¥" + total);
            
            request.setAttribute("cartItems", cartItems);
            System.out.println("正在跳转到购物车页面...");
            request.getRequestDispatcher("/cart.jsp").forward(request, response);
        } catch (SQLException e) {
            System.err.println("查询购物车失败:");
            System.err.println("错误: " + e.getMessage());
            request.setAttribute("error", "获取购物车信息失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    /**
     * 添加商品到购物车
     */
    private void addToCart(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        System.out.println("===== 开始添加商品到购物车 =====");
        System.out.println("用户ID: " + user.getId());
        System.out.println("用户名: " + user.getUsername());
        
        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");
        String productName = request.getParameter("productName");
        String priceStr = request.getParameter("price");
        String stockStr = request.getParameter("stock");
        
        System.out.println("商品ID: " + productIdStr);
        System.out.println("商品名称: " + productName);
        System.out.println("商品价格: " + priceStr);
        System.out.println("商品库存: " + stockStr);
        System.out.println("购买数量: " + quantityStr);
        
        if (productIdStr == null || quantityStr == null) {
            System.out.println("添加失败: 参数不完整");
            request.setAttribute("error", "参数不完整");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;
        }
        
        try {
            int productId = Integer.parseInt(productIdStr);
            int quantity = Integer.parseInt(quantityStr);
            int stock = Integer.parseInt(stockStr);
            
            if (quantity <= 0) {
                System.out.println("添加失败: 数量必须大于0");
                request.setAttribute("error", "数量必须大于0");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
            
            if (quantity > stock) {
                System.out.println("添加失败: 数量超过库存");
                request.setAttribute("error", "库存不足");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
            
            // 检查商品是否存在
            System.out.println("检查商品信息...");
            Product product = productService.getById(productId);
            if (product == null) {
                System.out.println("添加失败: 商品不存在");
                request.setAttribute("error", "商品不存在");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
            
            System.out.println("商品存在: " + product.getName());
            System.out.println("商品价格: " + product.getPrice());
            System.out.println("实际库存: " + product.getStock());
            
            if (product.getStock() < quantity) {
                System.out.println("添加失败: 库存不足");
                request.setAttribute("error", "库存不足");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
            
            // 添加到购物车
            System.out.println("正在添加到购物车...");
            cartService.addToCart(user.getId(), productId, quantity);
            System.out.println("添加成功，正在跳转到购物车页面...");
            response.sendRedirect(request.getContextPath() + "/cart/");
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "参数格式错误");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "添加到购物车失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    /**
     * 更新购物车商品数量
     */
    private void updateCartItem(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        String cartIdStr = request.getParameter("cartId");
        String quantityStr = request.getParameter("quantity");
        
        if (cartIdStr == null || quantityStr == null) {
            request.setAttribute("error", "参数不完整");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;
        }
        
        try {
            int cartId = Integer.parseInt(cartIdStr);
            int quantity = Integer.parseInt(quantityStr);
            
            if (quantity <= 0) {
                request.setAttribute("error", "数量必须大于0");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
            
            cartService.updateCartItem(cartId, user.getId(), quantity);
            response.sendRedirect(request.getContextPath() + "/cart/");
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "参数格式错误");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "更新购物车失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    /**
     * 删除购物车商品
     */
    private void deleteCartItem(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        String cartIdStr = request.getParameter("cartId");
        
        if (cartIdStr == null) {
            request.setAttribute("error", "参数不完整");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;
        }
        
        try {
            int cartId = Integer.parseInt(cartIdStr);
            cartService.removeFromCartByCartId(cartId, user.getId());
            response.sendRedirect(request.getContextPath() + "/cart/");
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "参数格式错误");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "删除购物车项失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
    
    /**
     * 清空购物车
     */
    private void clearCart(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            cartService.clearCart(user.getId());
            response.sendRedirect(request.getContextPath() + "/products.jsp");
        } catch (SQLException e) {
            request.setAttribute("error", "清空购物车失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}