package com.example.demo1.util;

/**
 * 统一结果返回类
 * @param <T> 数据类型
 */
public class Result<T> {
    
    private boolean success;
    private String message;
    private T data;
    private int code;
    
    // 私有构造方法
    private Result(boolean success, String message, T data, int code) {
        this.success = success;
        this.message = message;
        this.data = data;
        this.code = code;
    }
    
    /**
     * 成功结果
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(true, "操作成功", data, 200);
    }
    
    /**
     * 成功结果（无数据）
     */
    public static <T> Result<T> success() {
        return new Result<>(true, "操作成功", null, 200);
    }
    
    /**
     * 成功结果（自定义消息）
     */
    public static <T> Result<T> success(String message, T data) {
        return new Result<>(true, message, data, 200);
    }
    
    /**
     * 失败结果
     */
    public static <T> Result<T> fail(String message) {
        return new Result<>(false, message, null, 400);
    }
    
    /**
     * 失败结果（自定义错误码）
     */
    public static <T> Result<T> fail(String message, int code) {
        return new Result<>(false, message, null, code);
    }
    
    /**
     * 系统错误结果
     */
    public static <T> Result<T> error(String message) {
        return new Result<>(false, message, null, 500);
    }
    
    /**
     * 系统错误结果（自定义错误码）
     */
    public static <T> Result<T> error(String message, int code) {
        return new Result<>(false, message, null, code);
    }
    
    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public T getData() {
        return data;
    }
    
    public void setData(T data) {
        this.data = data;
    }
    
    public int getCode() {
        return code;
    }
    
    public void setCode(int code) {
        this.code = code;
    }
    
    @Override
    public String toString() {
        return "Result{" +
                "success=" + success +
                ", message='" + message + '\'' +
                ", data=" + data +
                ", code=" + code +
                '}';
    }
}