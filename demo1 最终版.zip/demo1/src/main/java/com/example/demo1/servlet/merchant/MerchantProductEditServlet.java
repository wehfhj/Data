package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/merchant/product/edit")
public class MerchantProductEditServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 检查商家是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_product_list.jsp");
            return;
        }

        try {
            int productId = Integer.parseInt(idStr);
            Product product = productDAO.getById(productId);

            if (product == null) {
                request.setAttribute("error", "商品不存在");
            } else {
                request.setAttribute("product", product);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "无效的商品ID");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "获取商品信息失败：" + e.getMessage());
        }

        request.getRequestDispatcher("/merchant/product/edit_product.jsp").forward(request, response);
    }
}
