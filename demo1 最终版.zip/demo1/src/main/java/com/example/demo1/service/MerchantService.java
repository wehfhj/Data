package com.example.demo1.service;

import com.example.demo1.dao.MerchantDAO;
import com.example.demo1.entity.Merchant;
import com.example.demo1.util.ValidationUtil;

import java.sql.SQLException;

public class MerchantService {
    private MerchantDAO merchantDAO = new MerchantDAO();

    public void register(Merchant merchant) throws SQLException {
        // 验证商家名称格式
        if (merchant.getMerchantName() == null || merchant.getMerchantName().trim().length() < 2 || merchant.getMerchantName().trim().length() > 50) {
            throw new IllegalArgumentException("商家名称格式不正确，长度应为2-50个字符");
        }

        // 验证密码格式
        if (!ValidationUtil.isValidPassword(merchant.getPassword())) {
            throw new IllegalArgumentException("密码格式不正确，长度应为6-20个字符，包含字母和数字");
        }

        // 验证邮箱格式
        if (!ValidationUtil.isValidEmail(merchant.getContactEmail())) {
            throw new IllegalArgumentException("邮箱格式不正确");
        }

        // 验证手机号格式
        if (!ValidationUtil.isValidPhone(merchant.getPhone())) {
            throw new IllegalArgumentException("手机号格式不正确");
        }

        // 检查商家名称是否已存在
        if (merchantDAO.getByMerchantName(merchant.getMerchantName()) != null) {
            throw new IllegalArgumentException("商家名称已存在");
        }

        // 检查邮箱是否已存在
        if (merchantDAO.getByContactEmail(merchant.getContactEmail()) != null) {
            throw new IllegalArgumentException("邮箱已存在");
        }

        // 注册商家
        merchantDAO.add(merchant);
    }

    public Merchant login(String merchantName, String password) throws SQLException {
        Merchant merchant = merchantDAO.getByMerchantName(merchantName);
        if (merchant == null || !merchant.getPassword().equals(password)) {
            throw new IllegalArgumentException("商家名称或密码错误");
        }
        return merchant;
    }

    public Merchant getMerchantById(int id) throws SQLException {
        Merchant merchant = merchantDAO.getById(id);
        if (merchant == null) {
            throw new IllegalArgumentException("商家不存在");
        }
        return merchant;
    }

    public void updateMerchant(Merchant merchant) throws SQLException {
        // 验证商家名称格式
        if (merchant.getMerchantName() == null || merchant.getMerchantName().trim().length() < 2 || merchant.getMerchantName().trim().length() > 50) {
            throw new IllegalArgumentException("商家名称格式不正确，长度应为2-50个字符");
        }

        // 验证邮箱格式
        if (!ValidationUtil.isValidEmail(merchant.getContactEmail())) {
            throw new IllegalArgumentException("邮箱格式不正确");
        }

        // 验证手机号格式
        if (!ValidationUtil.isValidPhone(merchant.getPhone())) {
            throw new IllegalArgumentException("手机号格式不正确");
        }

        // 检查商家名称是否被其他商家使用
        Merchant existingMerchant = merchantDAO.getByMerchantName(merchant.getMerchantName());
        if (existingMerchant != null && existingMerchant.getId() != merchant.getId()) {
            throw new IllegalArgumentException("商家名称已被其他商家使用");
        }

        // 检查邮箱是否被其他商家使用
        existingMerchant = merchantDAO.getByContactEmail(merchant.getContactEmail());
        if (existingMerchant != null && existingMerchant.getId() != merchant.getId()) {
            throw new IllegalArgumentException("邮箱已被其他商家使用");
        }

        // 更新商家信息
        merchantDAO.update(merchant);
    }

    public void changePassword(int merchantId, String oldPassword, String newPassword) throws SQLException {
        Merchant merchant = merchantDAO.getById(merchantId);
        if (merchant == null) {
            throw new IllegalArgumentException("商家不存在");
        }

        // 验证旧密码
        if (!merchant.getPassword().equals(oldPassword)) {
            throw new IllegalArgumentException("旧密码错误");
        }

        // 验证新密码格式
        if (!ValidationUtil.isValidPassword(newPassword)) {
            throw new IllegalArgumentException("新密码格式不正确，长度应为6-20个字符，包含字母和数字");
        }

        // 更新密码
        merchant.setPassword(newPassword);
        merchantDAO.update(merchant);
    }
}