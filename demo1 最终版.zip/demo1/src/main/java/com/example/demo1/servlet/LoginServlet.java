package com.example.demo1.servlet;

import com.example.demo1.dao.MerchantDAO;
import com.example.demo1.dao.UserDAO;
import com.example.demo1.entity.Merchant;
import com.example.demo1.entity.User;
import com.example.demo1.util.PathUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDAO userDAO;
    private MerchantDAO merchantDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        merchantDAO = new MerchantDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 检查是否是商家登录请求
        String type = request.getParameter("type");
        if ("merchant".equals(type)) {
            request.setAttribute("loginType", "merchant");
        } else {
            request.setAttribute("loginType", "user");
        }
        // 显示登录页面
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String loginType = request.getParameter("loginType");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            if ("merchant".equals(loginType)) {
                // 商家登录处理
                handleMerchantLogin(request, response, username, password);
            } else {
                // 用户登录处理
                handleUserLogin(request, response, username, password);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    private void handleUserLogin(HttpServletRequest request, HttpServletResponse response, 
                            String username, String password) throws ServletException, IOException {
        
        System.out.println("开始用户登录验证...");
        System.out.println("用户名: " + username);
        
        if (username == null || username.trim().isEmpty()) {
            System.out.println("登录验证失败: 用户名为空");
            request.setAttribute("error", "请输入用户名");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        if (password == null || password.length() < 6) {
            System.out.println("登录验证失败: 密码长度不足");
            request.setAttribute("error", "密码长度不能少于6位");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        try {
            User user = userDAO.findByUsername(username.trim());
            
            if (user == null) {
                System.out.println("登录验证失败: 用户不存在 - " + username);
                System.out.println("正在跳转回登录页面...");
                request.setAttribute("error", "用户名或密码错误");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
                return;
            }

            String encryptedPassword = encryptPassword(password);
            System.out.println("输入密码加密后: " + encryptedPassword);
            System.out.println("数据库密码: " + user.getPassword());

            if (!encryptedPassword.equals(user.getPassword())) {
                System.out.println("登录验证失败: 密码不匹配");
                System.out.println("正在跳转回登录页面...");
                request.setAttribute("error", "用户名或密码错误");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
                return;
            }

            // 登录成功，创建会话
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getId());
            session.setAttribute("username", user.getUsername());
            session.setAttribute("loginType", "user");
            
            System.out.println("用户登录成功: " + user.getUsername());
            System.out.println("用户ID: " + user.getId());
            System.out.println("正在跳转到首页...");
            String redirectUrl = PathUtil.getResourcePath(request, "/index.jsp");
            System.out.println("跳转URL: " + redirectUrl);

            // 跳转到首页
            response.sendRedirect(redirectUrl);

        } catch (Exception e) {
            System.err.println("登录过程中发生错误: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "登录失败，请稍后重试");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    private void handleMerchantLogin(HttpServletRequest request, HttpServletResponse response,
                               String username, String password) throws ServletException, IOException {

        System.out.println("开始商家登录验证...");
        System.out.println("商家名: " + username);

        if (username == null || username.trim().isEmpty()) {
            System.out.println("登录验证失败: 商家名为空");
            request.setAttribute("error", "请输入商家名称");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        if (password == null || password.length() < 6) {
            System.out.println("登录验证失败: 密码长度不足");
            request.setAttribute("error", "密码长度不能少于6位");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        try {
            Merchant merchant = merchantDAO.getByMerchantName(username.trim());

            if (merchant == null) {
                System.out.println("登录验证失败: 商家不存在 - " + username);
                request.setAttribute("error", "商家名称或密码错误");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
                return;
            }

            String encryptedPassword = encryptPassword(password);
            System.out.println("输入密码加密后: " + encryptedPassword);
            System.out.println("数据库密码: " + merchant.getPassword());

            if (!encryptedPassword.equals(merchant.getPassword())) {
                System.out.println("登录验证失败: 密码不匹配");
                request.setAttribute("error", "商家名称或密码错误");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
                return;
            }

            // 登录成功，创建会话
            HttpSession session = request.getSession();
            session.setAttribute("merchant", merchant);
            session.setAttribute("merchantId", merchant.getId());
            session.setAttribute("merchantName", merchant.getMerchantName());
            session.setAttribute("loginType", "merchant");

            System.out.println("商家登录成功: " + merchant.getMerchantName());
            System.out.println("商家ID: " + merchant.getId());
            System.out.println("正在跳转到商家商品管理页面...");

            // 跳转到商家商品管理页面
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_product_list.jsp");

        } catch (Exception e) {
            System.err.println("商家登录过程中发生错误: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "登录失败，请稍后重试");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return password;
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // 处理登出请求
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect(PathUtil.getResourcePath(request, "/login.jsp?message=已安全退出"));
    }
}