package com.example.demo1.dao;

import com.example.demo1.entity.Comment;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentDAO {
    public void add(Comment comment) throws SQLException {
        String sql = "INSERT INTO comments (user_id, product_id, order_id, rating, content) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, comment.getUserId());
            stmt.setInt(2, comment.getProductId());
            stmt.setInt(3, comment.getOrderId());
            stmt.setInt(4, comment.getRating());
            stmt.setString(5, comment.getContent());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                comment.setId(rs.getInt(1));
            }
        }
    }

    public void update(Comment comment) throws SQLException {
        String sql = "UPDATE comments SET rating=?, content=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, comment.getRating());
            stmt.setString(2, comment.getContent());
            stmt.setInt(3, comment.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM comments WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public Comment getById(int id) throws SQLException {
        String sql = "SELECT * FROM comments WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToComment(rs);
            }
        }
        return null;
    }

    public List<Comment> getByProductId(int productId, int page, int pageSize) throws SQLException {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT * FROM comments WHERE product_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
        }
        return comments;
    }

    public List<Comment> getByUserId(int userId, int page, int pageSize) throws SQLException {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT * FROM comments WHERE user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        System.out.println("执行分页查询用户评价SQL: " + sql);
        System.out.println("用户ID: " + userId + ", 页码: " + page + ", 每页: " + pageSize);
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            System.out.println("准备执行查询...");
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
            System.out.println("查询到评价数量: " + comments.size());
        } catch (SQLException e) {
            System.err.println("分页查询用户评价失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return comments;
    }
    
    public List<Comment> findByUserId(int userId) throws SQLException {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT * FROM comments WHERE user_id=? ORDER BY create_time DESC";
        System.out.println("执行查询所有用户评价SQL: " + sql);
        System.out.println("用户ID: " + userId);

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            System.out.println("准备执行查询...");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
            System.out.println("查询到评价数量: " + comments.size());
        } catch (SQLException e) {
            System.err.println("查询所有用户评价失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return comments;
    }

    public Comment findByUserIdAndOrderId(int userId, int orderId) throws SQLException {
        String sql = "SELECT * FROM comments WHERE user_id=? AND order_id=?";
        System.out.println("执行查询用户订单评价SQL: " + sql);
        System.out.println("用户ID: " + userId + ", 订单ID: " + orderId);

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, orderId);
            System.out.println("准备执行查询...");

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Comment comment = mapResultSetToComment(rs);
                System.out.println("查询到评价");
                return comment;
            }
            System.out.println("未查询到评价");
        } catch (SQLException e) {
            System.err.println("查询用户订单评价失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("订单ID: " + orderId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return null;
    }

    public List<Comment> getByOrderId(int orderId) throws SQLException {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT * FROM comments WHERE order_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
        }
        return comments;
    }

    public double getAverageRatingByProductId(int productId) throws SQLException {
        String sql = "SELECT AVG(rating) FROM comments WHERE product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }

    public int getTotalCountByProductId(int productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM comments WHERE product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // 获取商家所有商品的平均评分
    public double getAverageRatingByMerchantId(int merchantId) throws SQLException {
        String sql = "SELECT AVG(c.rating) FROM comments c JOIN products p ON c.product_id = p.id WHERE p.merchant_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }

    // 获取商家的所有评论列表
    public List<Comment> getByMerchantId(int merchantId) throws SQLException {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT c.* FROM comments c JOIN products p ON c.product_id = p.id WHERE p.merchant_id=? ORDER BY c.create_time DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                comments.add(mapResultSetToComment(rs));
            }
        }
        return comments;
    }

    private Comment mapResultSetToComment(ResultSet rs) throws SQLException {
        Comment comment = new Comment();
        comment.setId(rs.getInt("id"));
        comment.setUserId(rs.getInt("user_id"));
        comment.setProductId(rs.getInt("product_id"));
        comment.setOrderId(rs.getInt("order_id"));
        comment.setRating(rs.getInt("rating"));
        comment.setContent(rs.getString("content"));

        // 尝试读取 create_time 字段
        try {
            comment.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            try {
                comment.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                comment.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段
        try {
            comment.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            try {
                comment.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                comment.setUpdateTime(null);
            }
        }

        return comment;
    }
}