package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/merchant/add_stock")
public class MerchantAddStockServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 检查商家是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchantId") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");

        if (productIdStr == null || productIdStr.isEmpty() || quantityStr == null || quantityStr.isEmpty()) {
            request.setAttribute("error", "参数不完整");
            request.getRequestDispatcher("/merchant/product/detail.jsp?id=" + productIdStr).forward(request, response);
            return;
        }

        try {
            int productId = Integer.parseInt(productIdStr);
            int quantity = Integer.parseInt(quantityStr);

            if (quantity <= 0) {
                request.setAttribute("error", "增加数量必须大于0");
                request.getRequestDispatcher("/merchant/product/detail.jsp?id=" + productId).forward(request, response);
                return;
            }

            Product product = productDAO.getById(productId);
            if (product == null) {
                request.setAttribute("error", "商品不存在");
                request.getRequestDispatcher("/merchant/product/detail.jsp?id=" + productId).forward(request, response);
                return;
            }

            // 增加库存
            int newStock = product.getStock() + quantity;
            product.setStock(newStock);
            productDAO.update(product);

            request.setAttribute("success", "成功增加 " + quantity + " 件库存，当前库存：" + newStock + " 件");
            request.setAttribute("product", product);

        } catch (NumberFormatException e) {
            request.setAttribute("error", "无效的参数格式");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "增加库存失败：" + e.getMessage());
        }

        request.getRequestDispatcher("/merchant/product/detail.jsp?id=" + productIdStr).forward(request, response);
    }
}
