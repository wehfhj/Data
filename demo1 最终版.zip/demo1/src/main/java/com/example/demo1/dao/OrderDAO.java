package com.example.demo1.dao;

import com.example.demo1.entity.Order;
import com.example.demo1.entity.OrderItem;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    public void add(Order order) throws SQLException {
        String sql = "INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, order.getOrderNo());
            stmt.setInt(2, order.getUserId());
            stmt.setDouble(3, order.getTotalAmount());
            stmt.setString(4, order.getStatus());
            stmt.setString(5, order.getReceiverName());
            stmt.setString(6, order.getReceiverPhone());
            stmt.setString(7, order.getReceiverAddress());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                order.setId(rs.getInt(1));
            }
        }
    }

    public void update(Order order) throws SQLException {
        String sql = "UPDATE orders SET total_amount=?, status=?, receiver_name=?, receiver_phone=?, receiver_address=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, order.getTotalAmount());
            stmt.setString(2, order.getStatus());
            stmt.setString(3, order.getReceiverName());
            stmt.setString(4, order.getReceiverPhone());
            stmt.setString(5, order.getReceiverAddress());
            stmt.setInt(6, order.getId());
            stmt.executeUpdate();
        }
    }

    public void updateStatus(int orderId, String status) throws SQLException {
        String sql = "UPDATE orders SET status=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, orderId);
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM orders WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public Order getById(int id) throws SQLException {
        String sql = "SELECT * FROM orders WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Order order = mapResultSetToOrder(rs);
                // 加载订单项
                if (order != null) {
                    List<OrderItem> items = getOrderItemsByOrderId(order.getId());
                    order.setOrderItems(items);
                }
                return order;
            }
        }
        return null;
    }

    private List<OrderItem> getOrderItemsByOrderId(int orderId) throws SQLException {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT * FROM order_items WHERE order_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                items.add(mapResultSetToOrderItem(rs));
            }
        }
        return items;
    }

    private OrderItem mapResultSetToOrderItem(ResultSet rs) throws SQLException {
        OrderItem item = new OrderItem();
        item.setId(rs.getInt("id"));
        item.setOrderId(rs.getInt("order_id"));
        item.setProductId(rs.getInt("product_id"));
        item.setProductName(rs.getString("product_name"));
        item.setPrice(rs.getDouble("price"));
        item.setQuantity(rs.getInt("quantity"));
        item.setSubtotal(rs.getDouble("subtotal"));

        // 尝试读取 create_time 字段
        try {
            item.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            try {
                item.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                item.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段
        try {
            item.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            try {
                item.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                item.setUpdateTime(null);
            }
        }

        return item;
    }

    public List<Order> getByUserId(int userId, int page, int pageSize) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        System.out.println("执行查询用户订单SQL: " + sql);
        System.out.println("用户ID: " + userId);
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            System.out.println("准备执行查询...");
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
            System.out.println("查询到订单数量: " + orders.size());
        } catch (SQLException e) {
            System.err.println("查询用户订单失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return orders;
    }
    
    public List<Order> findByUserId(int userId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_id=? ORDER BY create_time DESC";
        System.out.println("执行查询所有用户订单SQL: " + sql);
        System.out.println("用户ID: " + userId);

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            System.out.println("准备执行查询...");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
            System.out.println("查询到订单数量: " + orders.size());
        } catch (SQLException e) {
            System.err.println("查询所有用户订单失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return orders;
    }

    public Order findByOrderNo(String orderNo) throws SQLException {
        String sql = "SELECT * FROM orders WHERE order_no=?";
        System.out.println("执行查询订单SQL: " + sql);
        System.out.println("订单号: " + orderNo);

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, orderNo);
            System.out.println("准备执行查询...");

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Order order = mapResultSetToOrder(rs);
                System.out.println("查询到订单: " + order.getId());
                return order;
            }
        } catch (SQLException e) {
            System.err.println("查询订单失败:");
            System.err.println("SQL: " + sql);
            System.err.println("订单号: " + orderNo);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return null;
    }

    public List<Order> getByMerchantId(int merchantId, int page, int pageSize) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.merchant_id=? ORDER BY o.create_time DESC LIMIT ? OFFSET ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        }
        return orders;
    }

    public List<Order> getByMerchantId(int merchantId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.merchant_id=? ORDER BY o.create_time DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        }
        return orders;
    }

    public List<Order> getByMerchantIdAndOrderNo(int merchantId, String orderNo) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.merchant_id=? AND o.order_no=? ORDER BY o.create_time DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            stmt.setString(2, orderNo);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        }
        return orders;
    }

    public List<Order> getByMerchantIdAndStatus(int merchantId, String status) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.merchant_id=? AND o.status=? ORDER BY o.create_time DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            stmt.setString(2, status);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        }
        return orders;
    }

    public List<Order> getByStatus(String status, int page, int pageSize) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE status=? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }
        }
        return orders;
    }

    public int getTotalCountByUserId(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM orders WHERE user_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public int getTotalCountByMerchantId(int merchantId) throws SQLException {
        String sql = "SELECT COUNT(DISTINCT o.id) FROM orders o JOIN order_items oi ON o.id = oi.order_id JOIN products p ON oi.product_id = p.id WHERE p.merchant_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, merchantId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setId(rs.getInt("id"));
        order.setOrderNo(rs.getString("order_no"));
        order.setUserId(rs.getInt("user_id"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        order.setStatus(rs.getString("status"));
        order.setReceiverName(rs.getString("receiver_name"));
        order.setReceiverPhone(rs.getString("receiver_phone"));
        order.setReceiverAddress(rs.getString("receiver_address"));

        // 尝试读取 create_time 字段，如果不存在则尝试其他可能的字段名
        try {
            order.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            // 如果 create_time 不存在，尝试 created_at
            try {
                order.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                order.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段，如果不存在则尝试其他可能的字段名
        try {
            order.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            // 如果 update_time 不存在，尝试 updated_at
            try {
                order.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                order.setUpdateTime(null);
            }
        }

        return order;
    }
}