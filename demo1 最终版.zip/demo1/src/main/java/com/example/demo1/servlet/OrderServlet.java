package com.example.demo1.servlet;

import com.example.demo1.dao.OrderDAO;
import com.example.demo1.entity.Merchant;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.User;
import com.example.demo1.service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/order/*")
public class OrderServlet extends HttpServlet {
    private OrderDAO orderDAO;
    private OrderService orderService;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAO();
        orderService = new OrderService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");
        Merchant merchant = (Merchant) session.getAttribute("merchant");

        if (user == null && merchant == null) {
            response.sendRedirect(request.getContextPath() + "/login?message=请先登录");
            return;
        }

        try {
            String pathInfo = request.getPathInfo();
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("/list")) {
                List<Order> orders;

                if (merchant != null) {
                    // 商家查看自己的订单列表
                    orders = orderDAO.getByMerchantId(merchant.getId(), 1, 100);
                    request.setAttribute("orders", orders);
                    request.setAttribute("isMerchant", true);

                    System.out.println("===== 商家订单列表加载中 =====");
                    System.out.println("商家ID: " + merchant.getId());
                    System.out.println("订单数量: " + orders.size());
                    request.getRequestDispatcher("/merchant/orders.jsp").forward(request, response);
                } else {
                    // 用户查看自己的订单列表
                    orders = orderDAO.findByUserId(user.getId());
                    request.setAttribute("orders", orders);
                    request.setAttribute("isMerchant", false);

                    // 获取消息并清除
                    String message = (String) session.getAttribute("message");
                    if (message != null) {
                        request.setAttribute("message", message);
                        session.removeAttribute("message");
                    }

                    // 转发到订单列表页面
                    System.out.println("正在跳转到订单列表页面...");
                    System.out.println("用户ID: " + user.getId());
                    System.out.println("订单数量: " + orders.size());
                    request.getRequestDispatcher("/orders.jsp").forward(request, response);
                }
            } else if (pathInfo.equals("/checkout")) {
                // 显示订单确认页面
                if (merchant != null) {
                    response.sendRedirect(request.getContextPath() + "/merchant/merchant_order_list.jsp");
                    return;
                }
                request.getRequestDispatcher("/checkout.jsp").forward(request, response);
            } else if (pathInfo.equals("/create")) {
                // 显示创建订单页面
                if (merchant != null) {
                    response.sendRedirect(request.getContextPath() + "/merchant/merchant_order_list.jsp");
                    return;
                }
                request.getRequestDispatcher("/checkout.jsp").forward(request, response);
            } else if (pathInfo != null && pathInfo.startsWith("/pay/")) {
                // 支付订单
                if (merchant != null) {
                    response.sendRedirect(request.getContextPath() + "/merchant/merchant_order_list.jsp");
                    return;
                }
                String orderNo = pathInfo.substring("/pay/".length());
                handlePayment(request, response, user, orderNo);
            } else if (pathInfo != null && pathInfo.startsWith("/cancel/")) {
                // 取消订单
                if (merchant != null) {
                    response.sendRedirect(request.getContextPath() + "/merchant/merchant_order_list.jsp");
                    return;
                }
                String orderNo = pathInfo.substring("/cancel/".length());
                handleCancel(request, response, user, orderNo);
            } else if (pathInfo != null && pathInfo.startsWith("/ship/")) {
                // 商家发货
                if (merchant == null) {
                    response.sendRedirect(request.getContextPath() + "/login?message=请先登录商家账号");
                    return;
                }
                String orderNo = pathInfo.substring("/ship/".length());
                handleShip(request, response, merchant, orderNo);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "加载订单失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 设置请求编码
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?message=请先登录");
            return;
        }

        try {
            String pathInfo = request.getPathInfo();
            if (pathInfo == null || pathInfo.equals("/create")) {
                // 创建订单
                String receiverName = request.getParameter("receiverName");
                String receiverPhone = request.getParameter("receiverPhone");
                String receiverAddress = request.getParameter("receiverAddress");

                System.out.println("===== 开始创建订单 =====");
                System.out.println("用户ID: " + user.getId());
                System.out.println("收货人: " + receiverName);
                System.out.println("联系电话: " + receiverPhone);
                System.out.println("收货地址: " + receiverAddress);

                if (receiverName == null || receiverName.trim().isEmpty() ||
                    receiverPhone == null || receiverPhone.trim().isEmpty() ||
                    receiverAddress == null || receiverAddress.trim().isEmpty()) {
                    request.setAttribute("error", "请填写完整的收货信息");
                    request.getRequestDispatcher("/checkout.jsp").forward(request, response);
                    return;
                }

                // 创建订单
                Order order = orderService.createOrder(user.getId(), receiverName, receiverPhone, receiverAddress);

                System.out.println("订单创建成功: " + order.getOrderNo());

                // 添加成功消息到session
                session.setAttribute("message", "订单创建成功！订单号：" + order.getOrderNo());

                // 跳转到订单列表
                response.sendRedirect(request.getContextPath() + "/order/list");
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "处理订单失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    /**
     * 处理订单支付
     */
    private void handlePayment(HttpServletRequest request, HttpServletResponse response, User user, String orderNo)
            throws ServletException, IOException, SQLException {

        System.out.println("===== 开始支付订单 =====");
        System.out.println("订单号: " + orderNo);
        System.out.println("用户ID: " + user.getId());

        // 查询订单
        Order order = orderDAO.findByOrderNo(orderNo);
        if (order == null) {
            request.setAttribute("error", "订单不存在");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 验证订单属于该用户
        if (order.getUserId() != user.getId()) {
            request.setAttribute("error", "没有权限操作该订单");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 验证订单状态
        if (!"pending".equals(order.getStatus())) {
            request.setAttribute("error", "订单状态不正确，无法支付");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 更新订单状态为已付款
        order.setStatus("paid");
        orderDAO.update(order);

        System.out.println("订单支付成功: " + orderNo);

        // 添加成功消息到session
        HttpSession session = request.getSession();
        session.setAttribute("message", "订单支付成功！订单号：" + orderNo);

        // 跳转到订单列表
        response.sendRedirect(request.getContextPath() + "/order/list");
    }

    /**
     * 处理订单取消
     */
    private void handleCancel(HttpServletRequest request, HttpServletResponse response, User user, String orderNo)
            throws ServletException, IOException, SQLException {

        System.out.println("===== 开始取消订单 =====");
        System.out.println("订单号: " + orderNo);
        System.out.println("用户ID: " + user.getId());

        // 查询订单
        Order order = orderDAO.findByOrderNo(orderNo);
        if (order == null) {
            request.setAttribute("error", "订单不存在");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 验证订单属于该用户
        if (order.getUserId() != user.getId()) {
            request.setAttribute("error", "没有权限操作该订单");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 验证订单状态
        if (!"pending".equals(order.getStatus())) {
            request.setAttribute("error", "订单状态不正确，无法取消");
            request.getRequestDispatcher("/order/list").forward(request, response);
            return;
        }

        // 更新订单状态为已取消
        order.setStatus("cancelled");
        orderDAO.update(order);

        System.out.println("订单取消成功: " + orderNo);

        // 添加成功消息到session
        HttpSession session = request.getSession();
        session.setAttribute("message", "订单已取消！订单号：" + orderNo);

        // 跳转到订单列表
        response.sendRedirect(request.getContextPath() + "/order/list");
    }

    /**
     * 处理商家发货
     */
    private void handleShip(HttpServletRequest request, HttpServletResponse response, Merchant merchant, String orderNo)
            throws ServletException, IOException, SQLException {

        System.out.println("===== 开始商家发货 =====");
        System.out.println("订单号: " + orderNo);
        System.out.println("商家ID: " + merchant.getId());

        // 查询订单
        Order order = orderDAO.findByOrderNo(orderNo);
        if (order == null) {
            HttpSession session = request.getSession();
            session.setAttribute("error", "订单不存在");
            response.sendRedirect(request.getContextPath() + "/order/list");
            return;
        }

        // 验证订单状态
        if (!"paid".equals(order.getStatus())) {
            HttpSession session = request.getSession();
            session.setAttribute("error", "订单状态不正确，只能发货已付款的订单");
            response.sendRedirect(request.getContextPath() + "/order/list");
            return;
        }

        // 更新订单状态为已发货
        order.setStatus("shipped");
        orderDAO.update(order);

        System.out.println("订单发货成功: " + orderNo);

        // 添加成功消息到session
        HttpSession session = request.getSession();
        session.setAttribute("message", "订单已发货！订单号：" + orderNo);

        // 跳转到商家订单列表
        response.sendRedirect(request.getContextPath() + "/order/list");
    }
}
