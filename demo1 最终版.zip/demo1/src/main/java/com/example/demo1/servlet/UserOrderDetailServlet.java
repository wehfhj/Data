package com.example.demo1.servlet;

import com.example.demo1.dao.OrderDAO;
import com.example.demo1.dao.OrderItemDAO;
import com.example.demo1.entity.User;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.OrderItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/user/order-detail/*")
public class UserOrderDetailServlet extends HttpServlet {
    private OrderDAO orderDAO;
    private OrderItemDAO orderItemDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAO();
        orderItemDAO = new OrderItemDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // 获取订单ID
            String pathInfo = request.getPathInfo();
            if (pathInfo != null && pathInfo.length() > 1) {
                String orderIdStr = pathInfo.substring(1); // 去掉开头的 /
                try {
                    int orderId = Integer.parseInt(orderIdStr);

                    // 查询订单
                    Order order = orderDAO.getById(orderId);

                    if (order == null) {
                        request.setAttribute("error", "订单不存在");
                        response.sendRedirect(request.getContextPath() + "/order/list");
                        return;
                    }

                    // 验证订单属于该用户
                    if (order.getUserId() != user.getId()) {
                        request.setAttribute("error", "没有权限查看该订单");
                        response.sendRedirect(request.getContextPath() + "/order/list");
                        return;
                    }

                    // 设置订单到请求属性
                    request.setAttribute("order", order);

                    // 转发到订单详情页面
                    request.getRequestDispatcher("/user/order-detail.jsp").forward(request, response);

                } catch (NumberFormatException e) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST);
                }
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "加载订单失败：" + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/order/list");
        }
    }
}
