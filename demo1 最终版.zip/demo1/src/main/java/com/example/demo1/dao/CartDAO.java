package com.example.demo1.dao;

import com.example.demo1.entity.Cart;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    public void add(Cart cart) throws SQLException {
        String sql = "INSERT INTO cart (user_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, cart.getUserId());
            stmt.setInt(2, cart.getProductId());
            stmt.setInt(3, cart.getQuantity());
            stmt.setDouble(4, cart.getPrice());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                cart.setId(rs.getInt(1));
            }
        }
    }

    public void update(Cart cart) throws SQLException {
        String sql = "UPDATE cart SET quantity=?, price=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cart.getQuantity());
            stmt.setDouble(2, cart.getPrice());
            stmt.setInt(3, cart.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM cart WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public void deleteByUserIdAndProductId(int userId, int productId) throws SQLException {
        String sql = "DELETE FROM cart WHERE user_id=? AND product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        }
    }

    public Cart getById(int id) throws SQLException {
        String sql = "SELECT * FROM cart WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToCart(rs);
            }
        }
        return null;
    }

    public Cart getByUserIdAndProductId(int userId, int productId) throws SQLException {
        String sql = "SELECT * FROM cart WHERE user_id=? AND product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToCart(rs);
            }
        }
        return null;
    }

    public List<Cart> getByUserId(int userId) throws SQLException {
        List<Cart> carts = new ArrayList<>();
        String sql = "SELECT * FROM cart WHERE user_id=?";
        System.out.println("执行查询用户购物车SQL: " + sql);
        System.out.println("用户ID: " + userId);
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            System.out.println("准备执行查询...");
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                carts.add(mapResultSetToCart(rs));
            }
            System.out.println("查询到购物车商品数量: " + carts.size());
        } catch (SQLException e) {
            System.err.println("查询用户购物车失败:");
            System.err.println("SQL: " + sql);
            System.err.println("用户ID: " + userId);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return carts;
    }

    public void clearByUserId(int userId) throws SQLException {
        String sql = "DELETE FROM cart WHERE user_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        }
    }

    private Cart mapResultSetToCart(ResultSet rs) throws SQLException {
        Cart cart = new Cart();
        cart.setId(rs.getInt("id"));
        cart.setUserId(rs.getInt("user_id"));
        cart.setProductId(rs.getInt("product_id"));
        cart.setQuantity(rs.getInt("quantity"));
        cart.setPrice(rs.getDouble("price"));

        // 尝试读取 create_time 字段
        try {
            cart.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            try {
                cart.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                cart.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段
        try {
            cart.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            try {
                cart.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                cart.setUpdateTime(null);
            }
        }

        return cart;
    }
}