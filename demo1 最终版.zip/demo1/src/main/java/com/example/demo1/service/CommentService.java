package com.example.demo1.service;

import com.example.demo1.dao.CommentDAO;
import com.example.demo1.dao.OrderDAO;
import com.example.demo1.dao.OrderItemDAO;
import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Comment;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.OrderItem;
import com.example.demo1.entity.Product;

import java.sql.SQLException;
import java.util.List;

public class CommentService {
    private CommentDAO commentDAO = new CommentDAO();
    private ProductDAO productDAO = new ProductDAO();
    private OrderDAO orderDAO = new OrderDAO();
    private OrderItemDAO orderItemDAO = new OrderItemDAO();

    public void addComment(int userId, int productId, int orderId, int rating, String content) throws SQLException {
        // 验证商品是否存在
        Product product = productDAO.getById(productId);
        if (product == null) {
            throw new IllegalArgumentException("商品不存在");
        }

        // 验证订单是否存在且属于该用户
        Order order = orderDAO.getById(orderId);
        if (order == null) {
            throw new IllegalArgumentException("订单不存在");
        }
        if (order.getUserId() != userId) {
            throw new IllegalArgumentException("没有权限评论该订单");
        }

        // 验证订单是否已完成
        if (!order.getStatus().equals("COMPLETED")) {
            throw new IllegalArgumentException("只有已完成的订单才能评论");
        }

        // 验证用户是否购买过该商品
        boolean hasPurchased = false;
        List<OrderItem> orderItems = orderItemDAO.getByOrderId(orderId);
        for (OrderItem item : orderItems) {
            if (item.getProductId() == productId) {
                hasPurchased = true;
                break;
            }
        }
        if (!hasPurchased) {
            throw new IllegalArgumentException("没有购买过该商品，无法评论");
        }

        // 验证评分
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("评分必须在1-5之间");
        }

        // 验证评论内容
        if (content == null || content.trim().isEmpty() || content.length() > 500) {
            throw new IllegalArgumentException("评论内容不能为空且长度不能超过500个字符");
        }

        // 创建评论
        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setProductId(productId);
        comment.setOrderId(orderId);
        comment.setRating(rating);
        comment.setContent(content);

        // 保存评论
        commentDAO.add(comment);
    }

    public void updateComment(int commentId, int userId, int rating, String content) throws SQLException {
        // 验证评论是否存在
        Comment comment = commentDAO.getById(commentId);
        if (comment == null) {
            throw new IllegalArgumentException("评论不存在");
        }

        // 验证评论是否属于该用户
        if (comment.getUserId() != userId) {
            throw new IllegalArgumentException("没有权限修改该评论");
        }

        // 验证评分
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("评分必须在1-5之间");
        }

        // 验证评论内容
        if (content == null || content.trim().isEmpty() || content.length() > 500) {
            throw new IllegalArgumentException("评论内容不能为空且长度不能超过500个字符");
        }

        // 更新评论
        comment.setRating(rating);
        comment.setContent(content);
        commentDAO.update(comment);
    }

    public void deleteComment(int commentId, int userId) throws SQLException {
        // 验证评论是否存在
        Comment comment = commentDAO.getById(commentId);
        if (comment == null) {
            throw new IllegalArgumentException("评论不存在");
        }

        // 验证评论是否属于该用户
        if (comment.getUserId() != userId) {
            throw new IllegalArgumentException("没有权限删除该评论");
        }

        // 删除评论
        commentDAO.delete(commentId);
    }

    public Comment getCommentById(int commentId) throws SQLException {
        Comment comment = commentDAO.getById(commentId);
        if (comment == null) {
            throw new IllegalArgumentException("评论不存在");
        }
        return comment;
    }

    public List<Comment> getCommentsByProductId(int productId, int page, int pageSize) throws SQLException {
        return commentDAO.getByProductId(productId, page, pageSize);
    }

    public List<Comment> getCommentsByUserId(int userId, int page, int pageSize) throws SQLException {
        return commentDAO.getByUserId(userId, page, pageSize);
    }

    public double getAverageRatingByProductId(int productId) throws SQLException {
        return commentDAO.getAverageRatingByProductId(productId);
    }

    public int getCommentCountByProductId(int productId) throws SQLException {
        return commentDAO.getTotalCountByProductId(productId);
    }
}