package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/merchant/product/status")
public class MerchantProductStatusServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 检查商家是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        String idStr = request.getParameter("id");
        String statusStr = request.getParameter("status");

        if (idStr == null || idStr.isEmpty() || statusStr == null || statusStr.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_product_list.jsp");
            return;
        }

        try {
            int productId = Integer.parseInt(idStr);
            
            // 检查商品是否存在
            Product product = productDAO.getById(productId);
            if (product == null) {
                request.setAttribute("error", "商品不存在");
                request.getRequestDispatcher("/merchant/merchant_product_list.jsp").forward(request, response);
                return;
            }
            
            // 更新商品状态
            boolean active = "ACTIVE".equalsIgnoreCase(statusStr);
            product.setActive(active);
            productDAO.update(product);
            
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_product_list.jsp");
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "无效的商品ID");
            request.getRequestDispatcher("/merchant/merchant_product_list.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "更新商品状态失败：" + e.getMessage());
            request.getRequestDispatcher("/merchant/merchant_product_list.jsp").forward(request, response);
        }
    }
}
