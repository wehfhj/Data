package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/merchant/add")
public class MerchantProductAddServlet extends HttpServlet {
    private ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 检查商家是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        String name = request.getParameter("name");
        String priceStr = request.getParameter("price");
        String stockStr = request.getParameter("stock");
        String description = request.getParameter("description");
        String activeStr = request.getParameter("active");

        // 验证必填字段
        if (name == null || name.trim().isEmpty() || priceStr == null || priceStr.trim().isEmpty() || stockStr == null || stockStr.trim().isEmpty()) {
            request.setAttribute("error", "请填写所有必填字段（商品名称、价格、库存、图片、状态）");
            request.getRequestDispatcher("/merchant/product/add_product.jsp").forward(request, response);
            return;
        }

        // 验证商品状态是否已选择
        if (activeStr == null || activeStr.trim().isEmpty()) {
            request.setAttribute("error", "请选择商品状态");
            request.getRequestDispatcher("/merchant/product/add_product.jsp").forward(request, response);
            return;
        }

        try {
            double price = Double.parseDouble(priceStr);
            int stock = Integer.parseInt(stockStr);
            boolean active = "true".equals(activeStr);

            int merchantId = (Integer) session.getAttribute("merchantId");

            // 处理图片上传
            String imageUrl = "/images/products/default.jpg"; // 默认图片
            Part filePart = request.getPart("image");
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName();
                String uploadPath = getServletContext().getRealPath("/images/products/");
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }
                filePart.write(uploadPath + File.separator + fileName);
                imageUrl = "/images/products/" + fileName;
            }

            // 创建商品对象
            Product product = new Product();
            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setStock(stock);
            product.setImageUrl(imageUrl);
            product.setMerchantId(merchantId);
            product.setActive(active);

            // 保存到数据库
            productDAO.add(product);

            response.sendRedirect(request.getContextPath() + "/merchant/merchant_product_list.jsp");

        } catch (NumberFormatException e) {
            request.setAttribute("error", "价格或库存格式不正确");
            request.getRequestDispatcher("/merchant/product/add_product.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "添加商品失败：" + e.getMessage());
            request.getRequestDispatcher("/merchant/product/add_product.jsp").forward(request, response);
        }
    }
}
