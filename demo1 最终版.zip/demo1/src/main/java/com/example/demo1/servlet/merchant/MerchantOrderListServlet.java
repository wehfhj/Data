package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.OrderDAO;
import com.example.demo1.entity.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/merchant/order/list")
public class MerchantOrderListServlet extends HttpServlet {
    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 检查商家是否登录
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        try {
            int merchantId = (Integer) session.getAttribute("merchantId");

            // 获取筛选参数
            String orderNo = request.getParameter("orderNo");
            String status = request.getParameter("status");

            List<Order> orders;

            // 根据筛选条件查询订单
            if (orderNo != null && !orderNo.isEmpty()) {
                // 按订单号筛选
                orders = orderDAO.getByMerchantIdAndOrderNo(merchantId, orderNo);
            } else if (status != null && !status.isEmpty()) {
                // 按状态筛选
                orders = orderDAO.getByMerchantIdAndStatus(merchantId, status);
            } else {
                // 获取所有订单
                orders = orderDAO.getByMerchantId(merchantId);
            }

            request.setAttribute("orders", orders);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "获取订单列表失败：" + e.getMessage());
        }

        request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
    }
}
