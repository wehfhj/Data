package com.example.demo1.util;

import javax.servlet.http.HttpServletRequest;

public class PathUtil {
    /**
     * 获取上下文路径
     */
    public static String getBasePath(HttpServletRequest request) {
        String contextPath = request.getContextPath();
        if (contextPath == null || contextPath.isEmpty()) {
            return "";
        }
        return contextPath;
    }
    
    /**
     * 获取完整的资源路径
     */
    public static String getResourcePath(HttpServletRequest request, String path) {
        String contextPath = getBasePath(request);
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        return contextPath + path;
    }
}