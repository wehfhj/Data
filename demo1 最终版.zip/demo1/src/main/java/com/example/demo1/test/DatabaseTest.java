package com.example.demo1.test;

import com.example.demo1.util.DBUtil;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseTest {
    public static void main(String[] args) {
        try {
            Connection conn = DBUtil.getConnection();
            System.out.println("数据库连接成功！");
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM users");
            if (rs.next()) {
                System.out.println("users表中记录数: " + rs.getInt("count"));
            }
            
            rs = stmt.executeQuery("DESCRIBE users");
            System.out.println("users表结构:");
            while (rs.next()) {
                System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
            }
            
            conn.close();
        } catch (SQLException e) {
            System.err.println("数据库测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}