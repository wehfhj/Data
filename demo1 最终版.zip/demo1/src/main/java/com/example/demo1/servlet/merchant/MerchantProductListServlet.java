package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/merchant/product/list")
public class MerchantProductListServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        try {
            int merchantId = (Integer) session.getAttribute("merchantId");

            System.out.println("===== 商家商品列表加载中 =====");
            System.out.println("商家ID: " + merchantId);

            // 获取该商家的商品列表
            List<Product> products = productDAO.getByMerchantId(merchantId);

            System.out.println("查询到商品数量: " + products.size());

            for (Product product : products) {
                System.out.println("商品ID: " + product.getId() +
                                   ", 名称: " + product.getName() +
                                   ", 价格: " + product.getPrice() +
                                   ", 库存: " + product.getStock() +
                                   ", 状态: " + (product.isActive() ? "上架" : "下架"));
            }

            request.setAttribute("products", products);

            System.out.println("===== 商品列表加载完成 =====");
            request.getRequestDispatcher("/merchant/merchant_product_list.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "获取商品列表失败：" + e.getMessage());
            request.getRequestDispatcher("/merchant/merchant_product_list.jsp").forward(request, response);
        }
    }
}
