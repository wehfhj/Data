package com.example.demo1.util;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBUtil {
    private static DataSource dataSource;

    static {
        try {
            Properties props = new Properties();
            InputStream is = DBUtil.class.getClassLoader().getResourceAsStream("druid.properties");
            if (is == null) {
                System.err.println("错误：无法找到druid.properties配置文件");
                throw new RuntimeException("找不到druid.properties配置文件");
            }
            props.load(is);
            System.out.println("正在初始化数据库连接池...");
            System.out.println("数据库URL: " + props.getProperty("url"));
            System.out.println("用户名: " + props.getProperty("username"));
            
            dataSource = DruidDataSourceFactory.createDataSource(props);
            System.out.println("数据库连接池初始化成功！");
            
            // 测试连接
            Connection testConn = dataSource.getConnection();
            System.out.println("数据库连接测试成功！");
            testConn.close();
        } catch (Exception e) {
            System.err.println("初始化数据库连接池失败:");
            System.err.println("错误类型: " + e.getClass().getName());
            System.err.println("错误信息: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("初始化数据库连接池失败", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            Connection conn = dataSource.getConnection();
            System.out.println("成功获取数据库连接: " + conn);
            return conn;
        } catch (SQLException e) {
            System.err.println("获取数据库连接失败:");
            System.err.println("错误代码: " + e.getErrorCode());
            System.err.println("SQL状态: " + e.getSQLState());
            System.err.println("错误信息: " + e.getMessage());
            throw e;
        }
    }

    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void close(Connection conn, Statement stmt) {
        close(conn, stmt, null);
    }
}