package com.example.demo1.service;

import com.example.demo1.dao.*;
import com.example.demo1.entity.*;

import java.sql.SQLException;
import java.util.List;

public class OrderService {
    private OrderDAO orderDAO = new OrderDAO();
    private OrderItemDAO orderItemDAO = new OrderItemDAO();
    private CartDAO cartDAO = new CartDAO();
    private ProductDAO productDAO = new ProductDAO();
    private UserDAO userDAO = new UserDAO();

    public Order createOrder(int userId, String receiverName, String receiverPhone, String receiverAddress) throws SQLException {
        System.out.println("OrderService: 开始创建订单");
        System.out.println("用户ID: " + userId);

        // 验证用户是否存在
        User user = userDAO.getById(userId);
        if (user == null) {
            throw new IllegalArgumentException("用户不存在");
        }
        System.out.println("用户存在: " + user.getUsername());

        // 获取用户购物车
        List<Cart> cartItems = cartDAO.getByUserId(userId);
        if (cartItems.isEmpty()) {
            throw new IllegalArgumentException("购物车为空，无法创建订单");
        }
        System.out.println("购物车商品数量: " + cartItems.size());

        // 生成订单号
        String orderNo = generateOrderNo();
        System.out.println("订单号: " + orderNo);

        // 创建订单
        Order order = new Order();
        order.setOrderNo(orderNo);
        order.setUserId(userId);
        order.setReceiverName(receiverName);
        order.setReceiverPhone(receiverPhone);
        order.setReceiverAddress(receiverAddress);
        order.setStatus("pending");

        // 计算订单总金额
        double totalAmount = 0;
        for (Cart cartItem : cartItems) {
            Product product = productDAO.getById(cartItem.getProductId());
            // 验证商品库存
            if (product.getStock() < cartItem.getQuantity()) {
                throw new IllegalArgumentException("商品 " + product.getName() + " 库存不足");
            }
            totalAmount += product.getPrice() * cartItem.getQuantity();
        }
        order.setTotalAmount(totalAmount);
        System.out.println("订单总金额: " + totalAmount);

        // 保存订单
        orderDAO.add(order);
        System.out.println("订单已保存，ID: " + order.getId());

        // 创建订单项
        for (Cart cartItem : cartItems) {
            Product product = productDAO.getById(cartItem.getProductId());

            // 创建订单项
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(order.getId());
            orderItem.setProductId(product.getId());
            orderItem.setProductName(product.getName());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(product.getPrice());
            orderItem.setSubtotal(product.getPrice() * cartItem.getQuantity());
            orderItemDAO.add(orderItem);

            // 减少商品库存
            product.setStock(product.getStock() - cartItem.getQuantity());
            productDAO.update(product);
        }
        System.out.println("订单项已创建");

        // 清空购物车
        cartDAO.clearByUserId(userId);
        System.out.println("购物车已清空");

        return order;
    }

    private String generateOrderNo() {
        // 生成订单号格式: ORD + 时间戳 + 随机数
        return "ORD" + System.currentTimeMillis() + (int)(Math.random() * 10000);
    }

    public Order getOrderById(int orderId) throws SQLException {
        Order order = orderDAO.getById(orderId);
        if (order == null) {
            throw new IllegalArgumentException("订单不存在");
        }
        return order;
    }

    public List<Order> getOrdersByUserId(int userId, int page, int pageSize) throws SQLException {
        return orderDAO.getByUserId(userId, page, pageSize);
    }

    public List<Order> getOrdersByMerchantId(int merchantId, int page, int pageSize) throws SQLException {
        return orderDAO.getByMerchantId(merchantId, page, pageSize);
    }

    public List<OrderItem> getOrderItemsByOrderId(int orderId) throws SQLException {
        return orderItemDAO.getByOrderId(orderId);
    }

    public void updateOrderStatus(int orderId, String status, int userId, boolean isMerchant) throws SQLException {
        // 验证订单是否存在
        Order order = orderDAO.getById(orderId);
        if (order == null) {
            throw new IllegalArgumentException("订单不存在");
        }

        // 验证权限
        if (isMerchant) {
            // 商家只能更新自己的订单
            List<OrderItem> orderItems = orderItemDAO.getByOrderId(orderId);
            boolean hasPermission = false;
            for (OrderItem item : orderItems) {
                Product product = productDAO.getById(item.getProductId());
                if (product.getMerchantId() == userId) {
                    hasPermission = true;
                    break;
                }
            }
            if (!hasPermission) {
                throw new IllegalArgumentException("没有权限更新该订单");
            }
        } else {
            // 用户只能更新自己的订单
            if (order.getUserId() != userId) {
                throw new IllegalArgumentException("没有权限更新该订单");
            }
        }

        // 更新订单状态
        orderDAO.updateStatus(orderId, status);
    }

    public int getTotalOrderCountByUserId(int userId) throws SQLException {
        return orderDAO.getTotalCountByUserId(userId);
    }

    public int getTotalOrderCountByMerchantId(int merchantId) throws SQLException {
        return orderDAO.getTotalCountByMerchantId(merchantId);
    }

    public int getOrderCountByUserId(int userId) throws SQLException {
        return getTotalOrderCountByUserId(userId);
    }

    public int getOrderCountByMerchantId(int merchantId) throws SQLException {
        return getTotalOrderCountByMerchantId(merchantId);
    }

    public void shipOrder(int orderId, int merchantId) throws SQLException {
        updateOrderStatus(orderId, "SHIPPED", merchantId, true);
    }

    public void cancelOrder(int orderId, int userId) throws SQLException {
        updateOrderStatus(orderId, "CANCELLED", userId, false);
    }
}