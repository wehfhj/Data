package com.example.demo1.dao;

import com.example.demo1.entity.OrderItem;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDAO {
    public void add(OrderItem orderItem) throws SQLException {
        String sql = "INSERT INTO order_items (order_id, product_id, product_name, price, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, orderItem.getOrderId());
            stmt.setInt(2, orderItem.getProductId());
            stmt.setString(3, orderItem.getProductName());
            stmt.setDouble(4, orderItem.getPrice());
            stmt.setInt(5, orderItem.getQuantity());
            stmt.setDouble(6, orderItem.getSubtotal());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                orderItem.setId(rs.getInt(1));
            }
        }
    }

    public void update(OrderItem orderItem) throws SQLException {
        String sql = "UPDATE order_items SET quantity=?, price=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderItem.getQuantity());
            stmt.setDouble(2, orderItem.getPrice());
            stmt.setInt(3, orderItem.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM order_items WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public void deleteByOrderId(int orderId) throws SQLException {
        String sql = "DELETE FROM order_items WHERE order_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            stmt.executeUpdate();
        }
    }

    public OrderItem getById(int id) throws SQLException {
        String sql = "SELECT * FROM order_items WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToOrderItem(rs);
            }
        }
        return null;
    }

    public List<OrderItem> getByOrderId(int orderId) throws SQLException {
        List<OrderItem> orderItems = new ArrayList<>();
        String sql = "SELECT * FROM order_items WHERE order_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orderItems.add(mapResultSetToOrderItem(rs));
            }
        }
        return orderItems;
    }

    public List<Integer> getProductIdsByOrderId(int orderId) throws SQLException {
        List<Integer> productIds = new ArrayList<>();
        String sql = "SELECT DISTINCT product_id FROM order_items WHERE order_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                productIds.add(rs.getInt("product_id"));
            }
        }
        return productIds;
    }

    public List<OrderItem> getByProductId(int productId, int page, int pageSize) throws SQLException {
        List<OrderItem> orderItems = new ArrayList<>();
        String sql = "SELECT * FROM order_items WHERE product_id=? ORDER BY create_time DESC LIMIT ? OFFSET ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            stmt.setInt(2, pageSize);
            stmt.setInt(3, (page - 1) * pageSize);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orderItems.add(mapResultSetToOrderItem(rs));
            }
        }
        return orderItems;
    }

    public int getTotalCountByProductId(int productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM order_items WHERE product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // 获取商品的销售数量（所有订单项的数量之和）
    public int getSoldCountByProductId(int productId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(quantity), 0) FROM order_items WHERE product_id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private OrderItem mapResultSetToOrderItem(ResultSet rs) throws SQLException {
        OrderItem orderItem = new OrderItem();
        orderItem.setId(rs.getInt("id"));
        orderItem.setOrderId(rs.getInt("order_id"));
        orderItem.setProductId(rs.getInt("product_id"));
        orderItem.setProductName(rs.getString("product_name"));
        orderItem.setQuantity(rs.getInt("quantity"));
        orderItem.setPrice(rs.getDouble("price"));
        orderItem.setSubtotal(rs.getDouble("subtotal"));

        // 尝试读取 create_time 字段
        try {
            orderItem.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            try {
                orderItem.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                orderItem.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段
        try {
            orderItem.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            try {
                orderItem.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                orderItem.setUpdateTime(null);
            }
        }

        return orderItem;
    }
}