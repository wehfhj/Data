package com.example.demo1.service;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    private ProductDAO productDAO = new ProductDAO();

    public void addProduct(Product product) throws SQLException {
        // 验证商品信息
        validateProduct(product);

        // 设置商品初始状态
        if (product.getStock() > 0) {
            product.setStatus("ACTIVE");
        } else {
            product.setStatus("OUT_OF_STOCK");
        }

        // 添加商品
        productDAO.add(product);
    }

    public void updateProduct(Product product) throws SQLException {
        // 验证商品信息
        validateProduct(product);

        // 更新商品状态
        if (product.getStock() > 0) {
            product.setStatus("ACTIVE");
        } else {
            product.setStatus("OUT_OF_STOCK");
        }

        // 更新商品
        productDAO.update(product);
    }

    public void deleteProduct(int productId, int merchantId) throws SQLException {
        // 验证商品是否存在
        Product product = productDAO.getById(productId);
        if (product == null) {
            throw new IllegalArgumentException("商品不存在");
        }

        // 验证商品是否属于该商家
        if (product.getMerchantId() != merchantId) {
            throw new IllegalArgumentException("没有权限删除该商品");
        }

        // 删除商品
        productDAO.delete(productId);
    }

    public Product getProductById(int productId) throws SQLException {
        System.out.println("ProductService: 查询商品详情，ID: " + productId);
        Product product = productDAO.getById(productId);
        if (product == null) {
            System.out.println("ProductService: 商品不存在 - " + productId);
            throw new IllegalArgumentException("商品不存在");
        }
        System.out.println("ProductService: 查询到商品 - " + product.getName());
        System.out.println("ProductService: 商品价格 - " + product.getPrice());
        System.out.println("ProductService: 商品库存 - " + product.getStock());
        return product;
    }

    public List<Product> getProductsByMerchantId(int merchantId, int page, int pageSize) throws SQLException {
        return productDAO.getByMerchantId(merchantId);
    }

    public List<Product> getAllProducts(int page, int pageSize) throws SQLException {
        return productDAO.getAll(page, pageSize);
    }

    public List<Product> searchProducts(String keyword, int page, int pageSize) throws SQLException {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllProducts(page, pageSize);
        }
        return productDAO.search(keyword, page, pageSize);
    }

    public List<Product> getProductsByCategory(String category, int page, int pageSize) throws SQLException {
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("分类不能为空");
        }
        return productDAO.getByCategory(category, page, pageSize);
    }

    public int getTotalProductCount() throws SQLException {
        return productDAO.getTotalProductCount();
    }

    public void updateProductStock(int productId, int quantity) throws SQLException {
        Product product = productDAO.getById(productId);
        if (product == null) {
            throw new IllegalArgumentException("商品不存在");
        }

        // 更新库存
        product.setStock(product.getStock() + quantity);

        // 更新商品状态
        if (product.getStock() > 0) {
            product.setStatus("ACTIVE");
        } else {
            product.setStatus("OUT_OF_STOCK");
        }

        productDAO.update(product);
    }

    public void updateProductStatus(int productId, String status) throws SQLException {
        Product product = productDAO.getById(productId);
        if (product == null) {
            throw new IllegalArgumentException("商品不存在");
        }

        // 更新商品状态
        product.setStatus(status);

        productDAO.update(product);
    }

    public int getTotalProductsCount() throws SQLException {
        return productDAO.getTotalCount();
    }

    public int getProductCountByMerchantId(int merchantId) throws SQLException {
        if (merchantId <= 0) {
            throw new IllegalArgumentException("商家ID无效");
        }
        return productDAO.getCountByMerchantId(merchantId);
    }

    public int getProductCountByKeyword(String keyword) throws SQLException {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getTotalProductsCount();
        }
        return productDAO.getProductCountByKeyword(keyword);
    }

    public int getProductCountByCategory(String category) throws SQLException {
        if (category == null || category.trim().isEmpty()) {
            throw new IllegalArgumentException("分类不能为空");
        }
        return productDAO.getProductCountByCategory(category);
    }

    /**
     * 根据ID获取商品
     */
    public Product getById(int productId) throws SQLException {
        if (productId <= 0) {
            throw new IllegalArgumentException("商品ID无效");
        }
        return productDAO.getById(productId);
    }

    private void validateProduct(Product product) {
        // 验证商品名称
        if (product.getName() == null || product.getName().trim().isEmpty() || product.getName().trim().length() > 100) {
            throw new IllegalArgumentException("商品名称格式不正确，长度应为1-100个字符");
        }

        // 验证商品描述
        if (product.getDescription() != null && product.getDescription().length() > 1000) {
            throw new IllegalArgumentException("商品描述过长，最大长度为1000个字符");
        }

        // 验证商品价格
        if (product.getPrice() <= 0) {
            throw new IllegalArgumentException("商品价格必须大于0");
        }

        // 验证商品库存
        if (product.getStock() < 0) {
            throw new IllegalArgumentException("商品库存不能为负数");
        }

        // 验证商家ID
        if (product.getMerchantId() <= 0) {
            throw new IllegalArgumentException("商家ID无效");
        }
    }
}