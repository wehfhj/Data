package com.example.demo1.servlet;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/product")
public class ProductDetailServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String idStr = request.getParameter("id");
            
            if (idStr == null || idStr.isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/products");
                return;
            }
            
            int productId = Integer.parseInt(idStr);
            System.out.println("获取商品详情，商品ID: " + productId);
            
            Product product = productDAO.getById(productId);
            
            if (product == null) {
                System.out.println("商品不存在，ID: " + productId);
                response.sendRedirect(request.getContextPath() + "/products?message=商品不存在");
                return;
            }
            
            System.out.println("获取到商品: " + product.getName());
            request.setAttribute("product", product);
            
            // 转发到商品详情页面
            request.getRequestDispatcher("/product-detail.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            System.err.println("商品ID格式错误: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/products?message=商品ID格式错误");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "加载商品详情失败：" + e.getMessage());
            request.getRequestDispatcher("/product-detail.jsp").forward(request, response);
        }
    }
}