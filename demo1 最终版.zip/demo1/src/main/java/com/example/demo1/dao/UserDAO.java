package com.example.demo1.dao;

import com.example.demo1.entity.User;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username=?";
        System.out.println("执行用户名查询: " + sql);
        System.out.println("查询参数: " + username);
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            System.out.println("准备执行查询...");
            
            ResultSet rs = stmt.executeQuery();
            boolean hasNext = rs.next();
            System.out.println("查询结果: " + (hasNext ? "找到用户" : "未找到用户"));
            
            if (hasNext) {
                User user = mapResultSetToUser(rs);
                System.out.println("用户信息: ID=" + user.getId() + ", 用户名=" + user.getUsername() + ", 邮箱=" + user.getEmail());
                return user;
            }
        } catch (SQLException e) {
            System.err.println("用户名查询失败:");
            System.err.println("SQL: " + sql);
            System.err.println("参数: " + username);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return null;
    }

    public boolean save(User user) {
        // 先尝试插入所有字段
        try {
            return saveWithAllFields(user);
        } catch (SQLException e) {
            if (e.getMessage().contains("Unknown column")) {
                System.out.println("检测到字段缺失，尝试只插入基本字段...");
                return saveWithBasicFields(user);
            } else {
                System.err.println("保存用户时发生SQL异常: " + e.getMessage());
                e.printStackTrace();
                return false;
            }
        } catch (Exception e) {
            System.err.println("保存用户时发生异常: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private boolean saveWithAllFields(User user) throws SQLException {
        String sql = "INSERT INTO users (username, password, email, phone, address, create_time) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getAddress());
            stmt.setTimestamp(6, user.getCreateTime() != null ? new Timestamp(user.getCreateTime().getTime()) : new Timestamp(System.currentTimeMillis()));
            
            System.out.println("执行完整字段SQL: " + sql);
            System.out.println("参数: " + user.getUsername() + ", " + user.getEmail() + ", " + user.getPhone() + ", " + user.getAddress());
            
            int result = stmt.executeUpdate();
            System.out.println("SQL执行结果: " + result);
            
            if (result > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    user.setId(rs.getInt(1));
                    System.out.println("生成用户ID: " + user.getId());
                }
                return true;
            }
            return false;
        }
    }
    
    private boolean saveWithBasicFields(User user) {
        String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            
            System.out.println("执行基本字段SQL: " + sql);
            System.out.println("参数: " + user.getUsername() + ", " + user.getEmail());
            
            int result = stmt.executeUpdate();
            System.out.println("SQL执行结果: " + result);
            
            if (result > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    user.setId(rs.getInt(1));
                    System.out.println("生成用户ID: " + user.getId());
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("保存用户时发生SQL异常: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("保存用户时发生异常: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public void add(User user) throws SQLException {
        String sql = "INSERT INTO users (username, password, email, phone, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getAddress());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                user.setId(rs.getInt(1));
            }
        }
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email=?";
        System.out.println("执行邮箱查询: " + sql);
        System.out.println("查询参数: " + email);
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            System.out.println("准备执行邮箱查询...");
            
            ResultSet rs = stmt.executeQuery();
            boolean hasNext = rs.next();
            System.out.println("邮箱查询结果: " + (hasNext ? "找到用户" : "未找到用户"));
            
            if (hasNext) {
                User user = mapResultSetToUser(rs);
                System.out.println("邮箱对应的用户: " + user.getUsername());
                return user;
            }
        } catch (SQLException e) {
            System.err.println("邮箱查询失败:");
            System.err.println("SQL: " + sql);
            System.err.println("参数: " + email);
            System.err.println("错误: " + e.getMessage());
            throw e;
        }
        return null;
    }

    public void update(User user) throws SQLException {
        String sql = "UPDATE users SET username=?, password=?, email=?, phone=?, address=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getAddress());
            stmt.setInt(6, user.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public User getById(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE id=?";
        System.out.println("执行ID查询: " + sql + " [id=" + id + "]");
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = mapResultSetToUser(rs);
                System.out.println("通过ID找到用户: " + user.getUsername());
                return user;
            } else {
                System.out.println("未找到ID为 " + id + " 的用户");
            }
        } catch (SQLException e) {
            System.err.println("ID查询失败: " + e.getMessage());
            throw e;
        }
        return null;
    }

    public User getByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToUser(rs);
            }
        }
        return null;
    }

    public User getByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToUser(rs);
            }
        }
        return null;
    }

    public List<User> getAll() throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }
        }
        return users;
    }

    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        System.out.println("开始映射ResultSet到User对象...");
        
        try {
            user.setId(rs.getInt("id"));
            System.out.println("ID: " + user.getId());
            
            user.setUsername(rs.getString("username"));
            System.out.println("用户名: " + user.getUsername());
            
            user.setPassword(rs.getString("password"));
            System.out.println("密码: [已加密]");
            
            user.setEmail(rs.getString("email"));
            System.out.println("邮箱: " + user.getEmail());
            
            user.setPhone(rs.getString("phone"));
            System.out.println("电话: " + (user.getPhone() != null ? user.getPhone() : "空"));
            
            user.setAddress(rs.getString("address"));
            System.out.println("地址: " + (user.getAddress() != null ? user.getAddress() : "空"));
            
            Timestamp createTime = rs.getTimestamp("create_time");
            if (createTime != null) {
                user.setCreateTime(new Date(createTime.getTime()));
                System.out.println("创建时间: " + user.getCreateTime());
            }
            
            Timestamp updateTime = rs.getTimestamp("update_time");
            if (updateTime != null) {
                user.setUpdateTime(new Date(updateTime.getTime()));
                System.out.println("更新时间: " + user.getUpdateTime());
            }
            
            System.out.println("User对象映射完成");
        } catch (SQLException e) {
            System.err.println("映射ResultSet到User时出错:");
            System.err.println("错误信息: " + e.getMessage());
            System.err.println("错误代码: " + e.getErrorCode());
            throw e;
        }
        return user;
    }
}