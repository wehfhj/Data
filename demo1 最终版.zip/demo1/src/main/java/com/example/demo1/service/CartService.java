package com.example.demo1.service;

import com.example.demo1.dao.CartDAO;
import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Cart;
import com.example.demo1.entity.Product;

import java.sql.SQLException;
import java.util.List;

public class CartService {
    private CartDAO cartDAO = new CartDAO();
    private ProductDAO productDAO = new ProductDAO();

    public void addToCart(int userId, int productId, int quantity) throws SQLException {
        System.out.println("CartService: 开始添加商品到购物车");
        System.out.println("用户ID: " + userId + ", 商品ID: " + productId + ", 数量: " + quantity);

        // 验证商品是否存在
        Product product = productDAO.getById(productId);
        if (product == null) {
            System.out.println("CartService: 商品不存在 - " + productId);
            throw new IllegalArgumentException("商品不存在");
        }

        // 验证商品是否有库存
        if (product.getStock() < quantity) {
            System.out.println("CartService: 库存不足 - 需要: " + quantity + ", 实际: " + product.getStock());
            throw new IllegalArgumentException("商品库存不足");
        }

        // 检查购物车中是否已存在该商品
        Cart existingCart = cartDAO.getByUserIdAndProductId(userId, productId);
        if (existingCart != null) {
            System.out.println("CartService: 购物车中已存在该商品，更新数量");
            System.out.println("原数量: " + existingCart.getQuantity() + ", 新数量: " + (existingCart.getQuantity() + quantity));
            // 更新购物车中该商品的数量
            existingCart.setQuantity(existingCart.getQuantity() + quantity);
            cartDAO.update(existingCart);
            System.out.println("CartService: 更新购物车成功");
        } else {
            System.out.println("CartService: 购物车中不存在该商品，添加新记录");
            // 添加新的购物车项
            Cart cart = new Cart();
            cart.setUserId(userId);
            cart.setProductId(productId);
            cart.setQuantity(quantity);
            cart.setPrice(product.getPrice());
            cartDAO.add(cart);
            System.out.println("CartService: 添加到购物车成功");
        }
    }

    public void updateCartItem(int cartId, int userId, int quantity) throws SQLException {
        // 验证购物车项是否存在
        Cart cart = cartDAO.getById(cartId);
        if (cart == null) {
            throw new IllegalArgumentException("购物车项不存在");
        }

        // 验证购物车项是否属于该用户
        if (cart.getUserId() != userId) {
            throw new IllegalArgumentException("没有权限修改该购物车项");
        }

        // 验证商品是否有足够的库存
        Product product = productDAO.getById(cart.getProductId());
        if (product.getStock() < quantity) {
            throw new IllegalArgumentException("商品库存不足");
        }

        // 更新购物车项数量
        cart.setQuantity(quantity);
        cartDAO.update(cart);
    }

    public void removeFromCartByCartId(int cartId, int userId) throws SQLException {
        // 验证购物车项是否存在
        Cart cart = cartDAO.getById(cartId);
        if (cart == null) {
            throw new IllegalArgumentException("购物车项不存在");
        }

        // 验证购物车项是否属于该用户
        if (cart.getUserId() != userId) {
            throw new IllegalArgumentException("没有权限删除该购物车项");
        }

        // 删除购物车项
        cartDAO.delete(cartId);
    }

    public void removeFromCart(int userId, int productId) throws SQLException {
        // 验证购物车项是否存在
        Cart cart = cartDAO.getByUserIdAndProductId(userId, productId);
        if (cart == null) {
            throw new IllegalArgumentException("购物车项不存在");
        }

        // 删除购物车项
        cartDAO.deleteByUserIdAndProductId(userId, productId);
    }

    public List<Cart> getCartByUserId(int userId) throws SQLException {
        return cartDAO.getByUserId(userId);
    }

    public List<Cart> getCartItems(int userId) throws SQLException {
        return cartDAO.getByUserId(userId);
    }

    public void updateCartItemQuantity(int userId, int productId, int quantity) throws SQLException {
        // 验证商品是否存在
        Product product = productDAO.getById(productId);
        if (product == null) {
            throw new IllegalArgumentException("商品不存在");
        }

        // 验证商品是否有库存
        if (product.getStock() < quantity) {
            throw new IllegalArgumentException("商品库存不足");
        }

        // 验证购物车项是否存在
        Cart cart = cartDAO.getByUserIdAndProductId(userId, productId);
        if (cart == null) {
            throw new IllegalArgumentException("购物车项不存在");
        }

        // 更新购物车项数量
        cart.setQuantity(quantity);
        cartDAO.update(cart);
    }

    public void clearCart(int userId) throws SQLException {
        cartDAO.clearByUserId(userId);
    }

    public Cart getCartItem(int userId, int productId) throws SQLException {
        return cartDAO.getByUserIdAndProductId(userId, productId);
    }
}