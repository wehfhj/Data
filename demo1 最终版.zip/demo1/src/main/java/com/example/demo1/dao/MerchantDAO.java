package com.example.demo1.dao;

import com.example.demo1.entity.Merchant;
import com.example.demo1.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MerchantDAO {
    public void add(Merchant merchant) throws SQLException {
        String sql = "INSERT INTO merchants (merchant_name, password, contact_email, phone, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, merchant.getMerchantName());
            stmt.setString(2, merchant.getPassword());
            stmt.setString(3, merchant.getContactEmail());
            stmt.setString(4, merchant.getPhone());
            stmt.setString(5, merchant.getAddress());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                merchant.setId(rs.getInt(1));
            }
        }
    }

    public void update(Merchant merchant) throws SQLException {
        String sql = "UPDATE merchants SET merchant_name=?, password=?, contact_email=?, phone=?, address=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, merchant.getMerchantName());
            stmt.setString(2, merchant.getPassword());
            stmt.setString(3, merchant.getContactEmail());
            stmt.setString(4, merchant.getPhone());
            stmt.setString(5, merchant.getAddress());
            stmt.setInt(6, merchant.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM merchants WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public Merchant getById(int id) throws SQLException {
        String sql = "SELECT * FROM merchants WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToMerchant(rs);
            }
        }
        return null;
    }

    public Merchant getByMerchantName(String merchantName) throws SQLException {
        String sql = "SELECT * FROM merchants WHERE merchant_name=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, merchantName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToMerchant(rs);
            }
        }
        return null;
    }

    public Merchant getByContactEmail(String contactEmail) throws SQLException {
        String sql = "SELECT * FROM merchants WHERE contact_email=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, contactEmail);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToMerchant(rs);
            }
        }
        return null;
    }

    public List<Merchant> getAll() throws SQLException {
        List<Merchant> merchants = new ArrayList<>();
        String sql = "SELECT * FROM merchants";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                merchants.add(mapResultSetToMerchant(rs));
            }
        }
        return merchants;
    }

    private Merchant mapResultSetToMerchant(ResultSet rs) throws SQLException {
        Merchant merchant = new Merchant();
        merchant.setId(rs.getInt("id"));
        merchant.setMerchantName(rs.getString("merchant_name"));
        merchant.setPassword(rs.getString("password"));
        merchant.setContactEmail(rs.getString("contact_email"));
        merchant.setPhone(rs.getString("phone"));
        merchant.setAddress(rs.getString("address"));

        // 尝试读取 create_time 字段
        try {
            merchant.setCreateTime(rs.getTimestamp("create_time"));
        } catch (SQLException e) {
            try {
                merchant.setCreateTime(rs.getTimestamp("created_at"));
            } catch (SQLException e2) {
                merchant.setCreateTime(null);
            }
        }

        // 尝试读取 update_time 字段
        try {
            merchant.setUpdateTime(rs.getTimestamp("update_time"));
        } catch (SQLException e) {
            try {
                merchant.setUpdateTime(rs.getTimestamp("updated_at"));
            } catch (SQLException e2) {
                merchant.setUpdateTime(null);
            }
        }

        return merchant;
    }
}