package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.OrderDAO;
import com.example.demo1.dao.OrderItemDAO;
import com.example.demo1.entity.Merchant;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.OrderItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/merchant/order-detail/*")
public class MerchantOrderDetailServlet extends HttpServlet {
    private OrderDAO orderDAO;
    private OrderItemDAO orderItemDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAO();
        orderItemDAO = new OrderItemDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Merchant merchant = (Merchant) session.getAttribute("merchant");

        if (merchant == null) {
            response.sendRedirect(request.getContextPath() + "/login?type=merchant");
            return;
        }

        try {
            // 获取订单ID
            String pathInfo = request.getPathInfo();
            if (pathInfo != null && pathInfo.length() > 1) {
                String orderIdStr = pathInfo.substring(1); // 去掉开头的 /
                try {
                    int orderId = Integer.parseInt(orderIdStr);

                    // 查询订单
                    Order order = orderDAO.getById(orderId);

                    if (order == null) {
                        request.setAttribute("error", "订单不存在");
                        response.sendRedirect(request.getContextPath() + "/merchant/orders");
                        return;
                    }

                    // 验证订单是否属于该商家
                    List<OrderItem> orderItems = orderItemDAO.getByOrderId(orderId);
                    boolean belongsToMerchant = false;
                    com.example.demo1.dao.ProductDAO productDAO = new com.example.demo1.dao.ProductDAO();

                    for (OrderItem item : orderItems) {
                        com.example.demo1.entity.Product product = productDAO.getById(item.getProductId());
                        if (product != null && product.getMerchantId() == merchant.getId()) {
                            belongsToMerchant = true;
                            break;
                        }
                    }

                    if (!belongsToMerchant) {
                        request.setAttribute("error", "没有权限查看该订单");
                        response.sendRedirect(request.getContextPath() + "/merchant/orders");
                        return;
                    }

                    // 设置订单到请求属性
                    request.setAttribute("order", order);

                    // 转发到订单详情页面
                    request.getRequestDispatcher("/merchant/order-detail.jsp").forward(request, response);

                } catch (NumberFormatException e) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST);
                }
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "加载订单失败：" + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/merchant/orders");
        }
    }
}
