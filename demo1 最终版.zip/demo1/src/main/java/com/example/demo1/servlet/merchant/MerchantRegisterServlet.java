package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.MerchantDAO;
import com.example.demo1.entity.Merchant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

@WebServlet("/merchant/register")
public class MerchantRegisterServlet extends HttpServlet {
    private MerchantDAO merchantDAO;

    @Override
    public void init() throws ServletException {
        merchantDAO = new MerchantDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/merchant-register.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String merchantName = request.getParameter("merchantName");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String contactEmail = request.getParameter("contactEmail");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        try {
            if (merchantName == null || merchantName.trim().isEmpty()) {
                System.out.println("验证失败: 商家名称为空");
                request.setAttribute("error", "商家名称不能为空");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            if (merchantName.trim().length() < 2 || merchantName.trim().length() > 50) {
                System.out.println("验证失败: 商家名称长度不正确");
                request.setAttribute("error", "商家名称长度应为2-50个字符");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            if (password == null || password.length() < 6 || password.length() > 20) {
                System.out.println("验证失败: 密码长度不正确");
                request.setAttribute("error", "密码长度应为6-20位");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            if (!password.equals(confirmPassword)) {
                System.out.println("验证失败: 两次密码不一致");
                request.setAttribute("error", "两次输入的密码不一致");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            if (contactEmail == null || !contactEmail.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                System.out.println("验证失败: 邮箱格式不正确");
                request.setAttribute("error", "请输入有效的邮箱地址");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            if (phone != null && !phone.trim().isEmpty() && !phone.matches("^1[3-9]\\d{9}$")) {
                System.out.println("验证失败: 手机号格式不正确");
                request.setAttribute("error", "请输入有效的手机号");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            // 检查商家名称是否已存在
            Merchant existingMerchant = merchantDAO.getByMerchantName(merchantName.trim());
            if (existingMerchant != null) {
                System.out.println("验证失败: 商家名称已存在 - " + merchantName);
                request.setAttribute("error", "商家名称已存在");
                request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                return;
            }

            // 检查邮箱是否已存在
            if (contactEmail != null && !contactEmail.trim().isEmpty()) {
                Merchant existingEmailMerchant = merchantDAO.getByContactEmail(contactEmail.trim());
                if (existingEmailMerchant != null) {
                    System.out.println("验证失败: 邮箱已存在 - " + contactEmail);
                    request.setAttribute("error", "该邮箱已被注册，请使用其他邮箱");
                    request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
                    return;
                }
            }

            Merchant merchant = new Merchant();
            merchant.setMerchantName(merchantName.trim());
            merchant.setPassword(encryptPassword(password));
            merchant.setContactEmail(contactEmail != null ? contactEmail.trim() : null);
            merchant.setPhone(phone != null ? phone.trim() : null);
            merchant.setAddress(address != null ? address.trim() : null);
            merchant.setCreateTime(new Date());

            System.out.println("准备注册商家:");
            System.out.println("商家名称: " + merchant.getMerchantName());
            System.out.println("邮箱: " + merchant.getContactEmail());

            merchantDAO.add(merchant);

            System.out.println("商家注册成功！");
            System.out.println("商家名称: " + merchant.getMerchantName());
            System.out.println("商家ID: " + merchant.getId());
            System.out.println("正在跳转到登录页面...");

            String loginUrl = request.getContextPath() + "/login?type=merchant&message=" +
                java.net.URLEncoder.encode("注册成功，请登录", "UTF-8") +
                "&username=" + java.net.URLEncoder.encode(merchantName, "UTF-8");
            System.out.println("跳转URL: " + loginUrl);
            response.sendRedirect(loginUrl);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("商家注册过程中发生错误: " + e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace(System.err);
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/merchant-register.jsp").forward(request, response);
        }
    }

    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return password;
        }
    }
}
