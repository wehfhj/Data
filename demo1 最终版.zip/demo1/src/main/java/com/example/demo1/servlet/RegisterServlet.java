package com.example.demo1.servlet;

import com.example.demo1.dao.UserDAO;
import com.example.demo1.entity.User;
import com.example.demo1.util.PathUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

@WebServlet("/user/register")
public class RegisterServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.sendRedirect(PathUtil.getResourcePath(request, "/register.jsp"));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        try {
            if (username == null || username.trim().isEmpty()) {
                System.out.println("验证失败: 用户名为空");
                request.setAttribute("error", "用户名不能为空");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

            if (password == null || password.length() < 6) {
                System.out.println("验证失败: 密码长度不足");
                request.setAttribute("error", "密码长度不能少于6位");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

            if (!password.equals(confirmPassword)) {
                System.out.println("验证失败: 两次密码不一致");
                request.setAttribute("error", "两次输入的密码不一致");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

            if (email == null || !email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                System.out.println("验证失败: 邮箱格式不正确");
                request.setAttribute("error", "请输入有效的邮箱地址");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

            User existingUser = userDAO.findByUsername(username.trim());
            if (existingUser != null) {
                System.out.println("验证失败: 用户名已存在 - " + username);
                request.setAttribute("error", "用户名已存在");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }

            // 检查邮箱是否已存在
            if (email != null && !email.trim().isEmpty()) {
                User existingEmailUser = userDAO.findByEmail(email.trim());
                if (existingEmailUser != null) {
                    System.out.println("验证失败: 邮箱已存在 - " + email);
                    request.setAttribute("error", "该邮箱已被注册，请使用其他邮箱");
                    request.getRequestDispatcher("/register.jsp").forward(request, response);
                    return;
                }
            }

            User user = new User();
            user.setUsername(username.trim());
            user.setPassword(encryptPassword(password));
            user.setEmail(email != null ? email.trim() : null);
            user.setPhone(phone != null ? phone.trim() : null);
            user.setAddress(address != null ? address.trim() : null);
            user.setCreateTime(new Date());
            System.out.println(user);

            boolean success = userDAO.save(user);
            
            if (success) {
                System.out.println("注册成功！");
                System.out.println("用户名: " + username);
                System.out.println("邮箱: " + email);
                System.out.println("正在跳转到登录页面...");
                
                String basePath = PathUtil.getResourcePath(request, "");
                String loginUrl = basePath + "/login.jsp?message=" + 
                    java.net.URLEncoder.encode("注册成功，请登录", "UTF-8") + 
                    "&username=" + java.net.URLEncoder.encode(username, "UTF-8");
                System.out.println("跳转URL: " + loginUrl);
                response.sendRedirect(loginUrl);
            } else {
                request.setAttribute("error", "注册失败，请稍后重试");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("注册过程中发生错误: " + e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace(System.err);
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/register.jsp").forward(request, response);
        }
    }

    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return password;
        }
    }
}