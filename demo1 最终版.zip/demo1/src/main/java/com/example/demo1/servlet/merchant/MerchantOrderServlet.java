package com.example.demo1.servlet.merchant;

import com.example.demo1.dao.OrderDAO;
import com.example.demo1.dao.OrderItemDAO;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.OrderItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/merchant/order")
public class MerchantOrderServlet extends HttpServlet {
    private OrderDAO orderDAO;
    private OrderItemDAO orderItemDAO;

    @Override
    public void init() throws ServletException {
        orderDAO = new OrderDAO();
        orderItemDAO = new OrderItemDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("merchant") == null) {
            response.sendRedirect(request.getContextPath() + "/merchant/merchant_login.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        try {
            switch (action) {
                case "detail":
                    showOrderDetail(request, response);
                    break;
                case "ship":
                    shipOrder(request, response);
                    break;
                case "cancel":
                    cancelOrder(request, response);
                    break;
                default:
                    listOrders(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "操作失败：" + e.getMessage());
            request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
        }
    }

    private void listOrders(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        request.getRequestDispatcher("/merchant/order/list").forward(request, response);
    }

    private void showOrderDetail(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int orderId = Integer.parseInt(request.getParameter("id"));
        Order order = orderDAO.getById(orderId);

        if (order == null) {
            request.setAttribute("error", "订单不存在");
            request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
            return;
        }

        List<OrderItem> orderItems = orderItemDAO.getByOrderId(orderId);
        order.setOrderItems(orderItems);

        request.setAttribute("order", order);
        request.getRequestDispatcher("/merchant/merchant_order_detail.jsp").forward(request, response);
    }

    private void shipOrder(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int orderId = Integer.parseInt(request.getParameter("id"));
        Order order = orderDAO.getById(orderId);

        if (order == null) {
            request.setAttribute("error", "订单不存在");
            request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
            return;
        }

        if (!"paid".equals(order.getStatus())) {
            request.setAttribute("error", "只有已付款的订单才能发货");
            request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
            return;
        }

        orderDAO.updateStatus(orderId, "shipped");
        request.setAttribute("success", "订单发货成功");
        request.getRequestDispatcher("/merchant/order/list").forward(request, response);
    }

    private void cancelOrder(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int orderId = Integer.parseInt(request.getParameter("id"));
        Order order = orderDAO.getById(orderId);

        if (order == null) {
            request.setAttribute("error", "订单不存在");
            request.getRequestDispatcher("/merchant/merchant_order_list.jsp").forward(request, response);
            return;
        }

        orderDAO.updateStatus(orderId, "cancelled");
        request.setAttribute("success", "订单已取消");
        request.getRequestDispatcher("/merchant/order/list").forward(request, response);
    }
}
