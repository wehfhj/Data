package com.example.demo1.servlet;

import com.example.demo1.dao.ProductDAO;
import com.example.demo1.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/products")
public class ProductListServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        productDAO = new ProductDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // 获取分页参数
            String pageStr = request.getParameter("page");
            String sizeStr = request.getParameter("size");
            String search = request.getParameter("search");
            
            int page = 1;
            int size = 12;
            
            if (pageStr != null && !pageStr.isEmpty()) {
                try {
                    page = Integer.parseInt(pageStr);
                } catch (NumberFormatException e) {
                    page = 1;
                }
            }
            
            if (sizeStr != null && !sizeStr.isEmpty()) {
                try {
                    size = Integer.parseInt(sizeStr);
                } catch (NumberFormatException e) {
                    size = 12;
                }
            }
            
            // 查询商品
            List<Product> products;
            if (search != null && !search.trim().isEmpty()) {
                products = productDAO.searchByName(search.trim());
                request.setAttribute("search", search.trim());
            } else {
                products = productDAO.findAll();
            }
            
            request.setAttribute("products", products);
            request.setAttribute("currentPage", page);
            request.setAttribute("pageSize", size);
            
            // 转发到商品列表页面
            System.out.println("正在跳转到商品列表页面...");
            System.out.println("商品数量: " + products.size());
            if (search != null) {
                System.out.println("搜索关键词: " + search);
            }
            request.getRequestDispatcher("/products.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "加载商品失败：" + e.getMessage());
            request.getRequestDispatcher("/products.jsp").forward(request, response);
        }
    }
}