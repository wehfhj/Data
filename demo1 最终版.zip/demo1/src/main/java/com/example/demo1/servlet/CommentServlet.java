package com.example.demo1.servlet;

import com.example.demo1.dao.CommentDAO;
import com.example.demo1.dao.OrderDAO;
import com.example.demo1.dao.OrderItemDAO;
import com.example.demo1.entity.Comment;
import com.example.demo1.entity.Order;
import com.example.demo1.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/comments")
public class CommentServlet extends HttpServlet {
    private CommentDAO commentDAO;
    private OrderDAO orderDAO;
    private OrderItemDAO orderItemDAO;

    @Override
    public void init() throws ServletException {
        commentDAO = new CommentDAO();
        orderDAO = new OrderDAO();
        orderItemDAO = new OrderItemDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?message=请先登录");
            return;
        }

        try {
            String action = request.getParameter("action");

            if ("view".equals(action)) {
                // 查看某个订单的评价 - 转发到评价页面
                String orderIdStr = request.getParameter("orderId");
                if (orderIdStr != null && !orderIdStr.isEmpty()) {
                    int orderId = Integer.parseInt(orderIdStr);
                    List<Comment> comments = commentDAO.getByOrderId(orderId);
                    request.setAttribute("comments", comments);
                    request.setAttribute("orderId", orderId);

                    // 获取订单信息
                    Order order = orderDAO.getById(orderId);
                    if (order != null) {
                        request.setAttribute("order", order);
                    }
                }
                // 转发到评价单个订单的页面
                request.getRequestDispatcher("/comment.jsp").forward(request, response);
            } else {
                // 获取用户的评价列表
                List<Comment> comments = commentDAO.findByUserId(user.getId());
                request.setAttribute("comments", comments);
                // 转发到用户所有评价列表页面
                request.getRequestDispatcher("/comments.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "加载评价失败：" + e.getMessage());
            request.getRequestDispatcher("/comment.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 设置请求编码
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?message=请先登录");
            return;
        }

        try {
            String action = request.getParameter("action");

            if ("add".equals(action)) {
                // 添加评价
                int orderId = Integer.parseInt(request.getParameter("orderId"));
                int productId = 0;
                int rating = Integer.parseInt(request.getParameter("rating"));
                String content = request.getParameter("content");

                // 从订单项获取第一个商品ID
                List<Integer> orderItems = orderItemDAO.getProductIdsByOrderId(orderId);
                if (!orderItems.isEmpty()) {
                    productId = orderItems.get(0);
                }

                System.out.println("===== 开始添加评价 =====");
                System.out.println("用户ID: " + user.getId());
                System.out.println("订单ID: " + orderId);
                System.out.println("商品ID: " + productId);
                System.out.println("评分: " + rating);

                // 验证订单存在且属于该用户
                Order order = orderDAO.getById(orderId);
                if (order == null) {
                    request.setAttribute("error", "订单不存在");
                    response.sendRedirect(request.getContextPath() + "/order/list");
                    return;
                }

                if (order.getUserId() != user.getId()) {
                    request.setAttribute("error", "没有权限评价该订单");
                    response.sendRedirect(request.getContextPath() + "/order/list");
                    return;
                }

                // 验证订单状态（只有已付款或已送达的订单才能评价）
                if (!"paid".equals(order.getStatus()) && !"delivered".equals(order.getStatus())) {
                    request.setAttribute("error", "订单状态不正确，只有已付款或已送达的订单才能评价");
                    response.sendRedirect(request.getContextPath() + "/order/list");
                    return;
                }

                // 检查是否已经评价过
                Comment existingComment = commentDAO.findByUserIdAndOrderId(user.getId(), orderId);
                if (existingComment != null) {
                    request.setAttribute("error", "您已经评价过该订单");
                    response.sendRedirect(request.getContextPath() + "/order/list");
                    return;
                }

                // 添加评价
                Comment comment = new Comment();
                comment.setUserId(user.getId());
                comment.setOrderId(orderId);
                comment.setProductId(productId);
                comment.setRating(rating);
                comment.setContent(content);
                commentDAO.add(comment);

                System.out.println("评价添加成功");

                // 添加成功消息到session
                session.setAttribute("message", "评价成功！感谢您的反馈");

                // 跳转到订单列表
                response.sendRedirect(request.getContextPath() + "/order/list");
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "参数格式错误");
            response.sendRedirect(request.getContextPath() + "/order/list");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "处理评价失败：" + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}